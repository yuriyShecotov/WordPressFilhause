-- All In One WP Security & Firewall 4.4.9
-- MySQL dump
-- 2021-10-14 19:13:19

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `lh_aiowps_events`;

CREATE TABLE `lh_aiowps_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `lh_aiowps_failed_logins`;

CREATE TABLE `lh_aiowps_failed_logins` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `lh_aiowps_global_meta`;

CREATE TABLE `lh_aiowps_global_meta` (
  `meta_id` bigint NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `lh_aiowps_login_activity`;

CREATE TABLE `lh_aiowps_login_activity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `logout_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `lh_aiowps_login_activity` VALUES("1","1","@Filatov","2021-10-07 19:13:05","1000-10-10 10:00:00","127.0.0.1","","");
INSERT INTO `lh_aiowps_login_activity` VALUES("2","1","@Filatov","2021-10-07 20:58:43","1000-10-10 10:00:00","127.0.0.1","","");


DROP TABLE IF EXISTS `lh_aiowps_login_lockdown`;

CREATE TABLE `lh_aiowps_login_lockdown` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `release_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `lh_aiowps_permanent_block`;

CREATE TABLE `lh_aiowps_permanent_block` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `lh_commentmeta`;

CREATE TABLE `lh_commentmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `lh_comments`;

CREATE TABLE `lh_comments` (
  `comment_ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `lh_comments` VALUES("1","1","Автор комментария","wapuu@wordpress.example","https://wordpress.org/","","2021-10-06 11:21:30","2021-10-06 08:21:30","Привет! Это комментарий.
Чтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.
Аватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.","0","post-trashed","","comment","0","0");


DROP TABLE IF EXISTS `lh_links`;

CREATE TABLE `lh_links` (
  `link_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint unsigned NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `lh_options`;

CREATE TABLE `lh_options` (
  `option_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=471 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `lh_options` VALUES("1","siteurl","http://localhost","yes");
INSERT INTO `lh_options` VALUES("2","home","http://localhost","yes");
INSERT INTO `lh_options` VALUES("3","blogname","Filhause","yes");
INSERT INTO `lh_options` VALUES("4","blogdescription","ПРОИЗВОДСТВО ДОМОВ из клеёного бруса и оцилиндрованного бревна","yes");
INSERT INTO `lh_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `lh_options` VALUES("6","admin_email","schekotov@outlook.com","yes");
INSERT INTO `lh_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `lh_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `lh_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `lh_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `lh_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `lh_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `lh_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `lh_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `lh_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `lh_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `lh_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `lh_options` VALUES("18","default_category","1","yes");
INSERT INTO `lh_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `lh_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `lh_options` VALUES("21","default_pingback_flag","0","yes");
INSERT INTO `lh_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `lh_options` VALUES("23","date_format","d.m.Y","yes");
INSERT INTO `lh_options` VALUES("24","time_format","H:i","yes");
INSERT INTO `lh_options` VALUES("25","links_updated_date_format","d.m.Y H:i","yes");
INSERT INTO `lh_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `lh_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `lh_options` VALUES("28","permalink_structure","/%postname%/","yes");
INSERT INTO `lh_options` VALUES("29","rewrite_rules","a:111:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:42:\"post_type_name/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:52:\"post_type_name/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:72:\"post_type_name/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"post_type_name/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"post_type_name/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:48:\"post_type_name/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"post_type_name/([^/]+)/embed/?$\";s:47:\"index.php?post_type_name=$matches[1]&embed=true\";s:35:\"post_type_name/([^/]+)/trackback/?$\";s:41:\"index.php?post_type_name=$matches[1]&tb=1\";s:43:\"post_type_name/([^/]+)/page/?([0-9]{1,})/?$\";s:54:\"index.php?post_type_name=$matches[1]&paged=$matches[2]\";s:50:\"post_type_name/([^/]+)/comment-page-([0-9]{1,})/?$\";s:54:\"index.php?post_type_name=$matches[1]&cpage=$matches[2]\";s:39:\"post_type_name/([^/]+)(?:/([0-9]+))?/?$\";s:53:\"index.php?post_type_name=$matches[1]&page=$matches[2]\";s:31:\"post_type_name/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"post_type_name/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"post_type_name/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"post_type_name/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"post_type_name/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"post_type_name/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=53&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `lh_options` VALUES("30","hack_file","0","yes");
INSERT INTO `lh_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `lh_options` VALUES("32","moderation_keys","","no");
INSERT INTO `lh_options` VALUES("33","active_plugins","a:3:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:3;s:45:\"enable-svg-webp-ico-upload/itc-svg-upload.php\";}","yes");
INSERT INTO `lh_options` VALUES("34","category_base","","yes");
INSERT INTO `lh_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `lh_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `lh_options` VALUES("37","gmt_offset","3","yes");
INSERT INTO `lh_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `lh_options` VALUES("39","recently_edited","a:2:{i:0;s:95:\"D:\\OpenServer\\domains\\localhost\\wordpress/wp-content/plugins/advanced-custom-fields-pro/acf.php\";i:1;s:0:\"\";}","no");
INSERT INTO `lh_options` VALUES("40","template","filhause","yes");
INSERT INTO `lh_options` VALUES("41","stylesheet","filhause","yes");
INSERT INTO `lh_options` VALUES("42","comment_registration","0","yes");
INSERT INTO `lh_options` VALUES("43","html_type","text/html","yes");
INSERT INTO `lh_options` VALUES("44","use_trackback","0","yes");
INSERT INTO `lh_options` VALUES("45","default_role","subscriber","yes");
INSERT INTO `lh_options` VALUES("46","db_version","49752","yes");
INSERT INTO `lh_options` VALUES("47","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `lh_options` VALUES("48","upload_path","","yes");
INSERT INTO `lh_options` VALUES("49","blog_public","0","yes");
INSERT INTO `lh_options` VALUES("50","default_link_category","2","yes");
INSERT INTO `lh_options` VALUES("51","show_on_front","page","yes");
INSERT INTO `lh_options` VALUES("52","tag_base","","yes");
INSERT INTO `lh_options` VALUES("53","show_avatars","1","yes");
INSERT INTO `lh_options` VALUES("54","avatar_rating","G","yes");
INSERT INTO `lh_options` VALUES("55","upload_url_path","","yes");
INSERT INTO `lh_options` VALUES("56","thumbnail_size_w","150","yes");
INSERT INTO `lh_options` VALUES("57","thumbnail_size_h","150","yes");
INSERT INTO `lh_options` VALUES("58","thumbnail_crop","1","yes");
INSERT INTO `lh_options` VALUES("59","medium_size_w","300","yes");
INSERT INTO `lh_options` VALUES("60","medium_size_h","300","yes");
INSERT INTO `lh_options` VALUES("61","avatar_default","mystery","yes");
INSERT INTO `lh_options` VALUES("62","large_size_w","1024","yes");
INSERT INTO `lh_options` VALUES("63","large_size_h","1024","yes");
INSERT INTO `lh_options` VALUES("64","image_default_link_type","none","yes");
INSERT INTO `lh_options` VALUES("65","image_default_size","","yes");
INSERT INTO `lh_options` VALUES("66","image_default_align","","yes");
INSERT INTO `lh_options` VALUES("67","close_comments_for_old_posts","0","yes");
INSERT INTO `lh_options` VALUES("68","close_comments_days_old","14","yes");
INSERT INTO `lh_options` VALUES("69","thread_comments","1","yes");
INSERT INTO `lh_options` VALUES("70","thread_comments_depth","5","yes");
INSERT INTO `lh_options` VALUES("71","page_comments","0","yes");
INSERT INTO `lh_options` VALUES("72","comments_per_page","50","yes");
INSERT INTO `lh_options` VALUES("73","default_comments_page","newest","yes");
INSERT INTO `lh_options` VALUES("74","comment_order","asc","yes");
INSERT INTO `lh_options` VALUES("75","sticky_posts","a:0:{}","yes");
INSERT INTO `lh_options` VALUES("76","widget_categories","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("77","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("78","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("79","uninstall_plugins","a:0:{}","no");
INSERT INTO `lh_options` VALUES("80","timezone_string","","yes");
INSERT INTO `lh_options` VALUES("81","page_for_posts","0","yes");
INSERT INTO `lh_options` VALUES("82","page_on_front","53","yes");
INSERT INTO `lh_options` VALUES("83","default_post_format","0","yes");
INSERT INTO `lh_options` VALUES("84","link_manager_enabled","0","yes");
INSERT INTO `lh_options` VALUES("85","finished_splitting_shared_terms","1","yes");
INSERT INTO `lh_options` VALUES("86","site_icon","48","yes");
INSERT INTO `lh_options` VALUES("87","medium_large_size_w","768","yes");
INSERT INTO `lh_options` VALUES("88","medium_large_size_h","0","yes");
INSERT INTO `lh_options` VALUES("89","wp_page_for_privacy_policy","3","yes");
INSERT INTO `lh_options` VALUES("90","show_comments_cookies_opt_in","1","yes");
INSERT INTO `lh_options` VALUES("91","admin_email_lifespan","1649060489","yes");
INSERT INTO `lh_options` VALUES("92","disallowed_keys","","no");
INSERT INTO `lh_options` VALUES("93","comment_previously_approved","1","yes");
INSERT INTO `lh_options` VALUES("94","auto_plugin_theme_update_emails","a:0:{}","no");
INSERT INTO `lh_options` VALUES("95","auto_update_core_dev","enabled","yes");
INSERT INTO `lh_options` VALUES("96","auto_update_core_minor","enabled","yes");
INSERT INTO `lh_options` VALUES("97","auto_update_core_major","enabled","yes");
INSERT INTO `lh_options` VALUES("98","wp_force_deactivated_plugins","a:0:{}","yes");
INSERT INTO `lh_options` VALUES("99","initial_db_version","49752","yes");
INSERT INTO `lh_options` VALUES("100","LH_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `lh_options` VALUES("101","fresh_site","0","yes");
INSERT INTO `lh_options` VALUES("102","WPLANG","ru_RU","yes");
INSERT INTO `lh_options` VALUES("103","widget_block","a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:167:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Свежие записи</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:247:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Свежие комментарии</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Архивы</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Рубрики</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("104","sidebars_widgets","a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `lh_options` VALUES("105","cron","a:8:{i:1633940490;a:5:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1633940499;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1633940500;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1633967749;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1634199690;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1634239290;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1634241349;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `lh_options` VALUES("106","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("107","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("108","widget_archives","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("109","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("110","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("111","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("112","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("113","widget_meta","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("114","widget_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("115","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("116","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("117","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("119","recovery_keys","a:0:{}","yes");
INSERT INTO `lh_options` VALUES("120","theme_mods_twentytwentyone","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1633508695;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}","yes");
INSERT INTO `lh_options` VALUES("122","https_detection_errors","a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:38:\"Проверка SSL неудачна.\";}}","yes");
INSERT INTO `lh_options` VALUES("133","_site_transient_timeout_browser_923aa2e1f4ca3e275e4d6d2229ceaf40","1634113299","no");
INSERT INTO `lh_options` VALUES("134","_site_transient_browser_923aa2e1f4ca3e275e4d6d2229ceaf40","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"93.0.4577.82\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `lh_options` VALUES("135","_site_transient_timeout_php_check_20f4df878f211a5689e76acb3f9067a8","1634113300","no");
INSERT INTO `lh_options` VALUES("136","_site_transient_php_check_20f4df878f211a5689e76acb3f9067a8","a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `lh_options` VALUES("144","can_compress_scripts","1","no");
INSERT INTO `lh_options` VALUES("151","recently_activated","a:2:{s:36:\"contact-form-7/wp-contact-form-7.php\";i:1633623293;s:35:\"wpcf7-recaptcha/wpcf7-recaptcha.php\";i:1633623207;}","yes");
INSERT INTO `lh_options` VALUES("160","acf_version","5.10.2","yes");
INSERT INTO `lh_options` VALUES("163","finished_updating_comment_type","1","yes");
INSERT INTO `lh_options` VALUES("168","current_theme","Filhause","yes");
INSERT INTO `lh_options` VALUES("169","theme_mods_filhause","a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `lh_options` VALUES("170","theme_switched","","yes");
INSERT INTO `lh_options` VALUES("173","widget_recent-posts","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("174","widget_recent-comments","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("178","ideastocode_module_settings","a:1:{s:14:\"itc_svg_upload\";a:5:{s:4:\"name\";s:14:\"itc_svg_upload\";s:5:\"title\";s:33:\"Enable SVG, WebP &amp; ICO Upload\";s:4:\"slug\";s:14:\"itc-svg-upload\";s:7:\"version\";s:5:\"1.0.1\";s:8:\"settings\";s:23:\"itc_svg_upload_settings\";}}","yes");
INSERT INTO `lh_options` VALUES("179","itc_svg_upload_settings","a:3:{s:3:\"svg\";i:1;s:4:\"webp\";i:1;s:3:\"ico\";i:1;}","yes");
INSERT INTO `lh_options` VALUES("182","_transient_itc_svg_upload_settings_notice_dismiss_alert","9","yes");
INSERT INTO `lh_options` VALUES("185","options_logo_header_logo_icon","50","no");
INSERT INTO `lh_options` VALUES("186","_options_logo_header_logo_icon","field_6157336b2c05f","no");
INSERT INTO `lh_options` VALUES("187","options_logo_header_logo_link","http://localhost/","no");
INSERT INTO `lh_options` VALUES("188","_options_logo_header_logo_link","field_615733b72c060","no");
INSERT INTO `lh_options` VALUES("189","options_logo_header","","no");
INSERT INTO `lh_options` VALUES("190","_options_logo_header","field_61572f175d223","no");
INSERT INTO `lh_options` VALUES("191","options_icon_header_whatsapps_whatsapp_icon","61","no");
INSERT INTO `lh_options` VALUES("192","_options_icon_header_whatsapps_whatsapp_icon","field_6159e184d3204","no");
INSERT INTO `lh_options` VALUES("193","options_icon_header_whatsapps_whatsapps_link","","no");
INSERT INTO `lh_options` VALUES("194","_options_icon_header_whatsapps_whatsapps_link","field_6159e184d3205","no");
INSERT INTO `lh_options` VALUES("195","options_icon_header_whatsapps","","no");
INSERT INTO `lh_options` VALUES("196","_options_icon_header_whatsapps","field_6159e184d3203","no");
INSERT INTO `lh_options` VALUES("197","options_icon_header_telegrams_telegram_icon","62","no");
INSERT INTO `lh_options` VALUES("198","_options_icon_header_telegrams_telegram_icon","field_6159e184d3207","no");
INSERT INTO `lh_options` VALUES("199","options_icon_header_telegrams_telegram_link","","no");
INSERT INTO `lh_options` VALUES("200","_options_icon_header_telegrams_telegram_link","field_6159e184d3208","no");
INSERT INTO `lh_options` VALUES("201","options_icon_header_telegrams","","no");
INSERT INTO `lh_options` VALUES("202","_options_icon_header_telegrams","field_6159e184d3206","no");
INSERT INTO `lh_options` VALUES("203","options_icon_header_instagrams_telegram_icon","63","no");
INSERT INTO `lh_options` VALUES("204","_options_icon_header_instagrams_telegram_icon","field_6159e184d320a","no");
INSERT INTO `lh_options` VALUES("205","options_icon_header_instagrams_instagram_link","","no");
INSERT INTO `lh_options` VALUES("206","_options_icon_header_instagrams_instagram_link","field_6159e184d320b","no");
INSERT INTO `lh_options` VALUES("207","options_icon_header_instagrams","","no");
INSERT INTO `lh_options` VALUES("208","_options_icon_header_instagrams","field_6159e184d3209","no");
INSERT INTO `lh_options` VALUES("209","options_icon_header_phone_icon","64","no");
INSERT INTO `lh_options` VALUES("210","_options_icon_header_phone_icon","field_6159e185d320d","no");
INSERT INTO `lh_options` VALUES("211","options_icon_header_phone_phone","+7 999 999 99 99","no");
INSERT INTO `lh_options` VALUES("212","_options_icon_header_phone_phone","field_6159e185d320e","no");
INSERT INTO `lh_options` VALUES("213","options_icon_header_phone","","no");
INSERT INTO `lh_options` VALUES("214","_options_icon_header_phone","field_6159e185d320c","no");
INSERT INTO `lh_options` VALUES("215","options_icon_header","","no");
INSERT INTO `lh_options` VALUES("216","_options_icon_header","field_6159e183d3202","no");
INSERT INTO `lh_options` VALUES("217","options_logo_footer_logo_icon","68","no");
INSERT INTO `lh_options` VALUES("218","_options_logo_footer_logo_icon","field_6159e101d3200","no");
INSERT INTO `lh_options` VALUES("219","options_logo_footer_logo_link","","no");
INSERT INTO `lh_options` VALUES("220","_options_logo_footer_logo_link","field_6159e101d3201","no");
INSERT INTO `lh_options` VALUES("221","options_logo_footer","","no");
INSERT INTO `lh_options` VALUES("222","_options_logo_footer","field_6159e101d31ff","no");
INSERT INTO `lh_options` VALUES("223","options_icon_footer_whatsapp_icon","69","no");
INSERT INTO `lh_options` VALUES("224","_options_icon_footer_whatsapp_icon","field_6159f5fb71c5e","no");
INSERT INTO `lh_options` VALUES("225","options_icon_footer_whatsapp_link","","no");
INSERT INTO `lh_options` VALUES("226","_options_icon_footer_whatsapp_link","field_6159f63571c5f","no");
INSERT INTO `lh_options` VALUES("227","options_icon_footer_whatsapp","","no");
INSERT INTO `lh_options` VALUES("228","_options_icon_footer_whatsapp","field_6159f5e471c5d","no");
INSERT INTO `lh_options` VALUES("229","options_icon_footer_instagram_icon","71","no");
INSERT INTO `lh_options` VALUES("230","_options_icon_footer_instagram_icon","field_6159f65571c61","no");
INSERT INTO `lh_options` VALUES("231","options_icon_footer_instagram_link","","no");
INSERT INTO `lh_options` VALUES("232","_options_icon_footer_instagram_link","field_6159f65571c62","no");
INSERT INTO `lh_options` VALUES("233","options_icon_footer_instagram","","no");
INSERT INTO `lh_options` VALUES("234","_options_icon_footer_instagram","field_6159f65571c60","no");
INSERT INTO `lh_options` VALUES("235","options_icon_footer_telegram_icon","70","no");
INSERT INTO `lh_options` VALUES("236","_options_icon_footer_telegram_icon","field_6159f68471c64","no");
INSERT INTO `lh_options` VALUES("237","options_icon_footer_telegram_link","","no");
INSERT INTO `lh_options` VALUES("238","_options_icon_footer_telegram_link","field_6159f68471c65","no");
INSERT INTO `lh_options` VALUES("239","options_icon_footer_telegram","","no");
INSERT INTO `lh_options` VALUES("240","_options_icon_footer_telegram","field_6159f68471c63","no");
INSERT INTO `lh_options` VALUES("241","options_icon_footer","","no");
INSERT INTO `lh_options` VALUES("242","_options_icon_footer","field_6159f5ab71c5c","no");
INSERT INTO `lh_options` VALUES("246","category_children","a:0:{}","yes");
INSERT INTO `lh_options` VALUES("247","_site_transient_timeout_browser_a44e7ab8cc69f9e2b9db9430df373653","1634117194","no");
INSERT INTO `lh_options` VALUES("248","_site_transient_browser_a44e7ab8cc69f9e2b9db9430df373653","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"94.0.4606.71\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `lh_options` VALUES("275","_transient_health-check-site-status-result","{\"good\":14,\"recommended\":5,\"critical\":0}","yes");
INSERT INTO `lh_options` VALUES("291","aiowpsec_db_version","1.9","yes");
INSERT INTO `lh_options` VALUES("292","aio_wp_security_configs","a:94:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:1:\"1\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:10;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:1:\"1\";s:20:\"aiowps_email_address\";s:21:\"schekotov@outlook.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"s343yc5l0d78jfueeeib\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"9vknntkeqsm5glu4gmzg\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:4;s:25:\"aiowps_db_backup_interval\";s:1:\"1\";s:26:\"aiowps_backup_files_stored\";i:3;s:32:\"aiowps_send_backup_email_address\";s:1:\"1\";s:27:\"aiowps_backup_email_address\";s:21:\"schekotov@outlook.com\";s:27:\"aiowps_disable_file_editing\";s:1:\"1\";s:37:\"aiowps_prevent_default_wp_file_access\";s:1:\"1\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:27:\"aiowps_max_file_upload_size\";i:10;s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:1:\"1\";s:34:\"aiowps_advanced_char_string_filter\";s:1:\"1\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:21:\"schekotov@outlook.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";s:28:\"aiowps_block_fake_googlebots\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2021-10-07 19:56:44\";}","yes");
INSERT INTO `lh_options` VALUES("303","auto_update_plugins","a:3:{i:0;s:35:\"wpcf7-recaptcha/wpcf7-recaptcha.php\";i:1;s:45:\"enable-svg-webp-ico-upload/itc-svg-upload.php\";i:2;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";}","no");
INSERT INTO `lh_options` VALUES("343","recovery_mode_email_last_sent","1633633148","yes");
INSERT INTO `lh_options` VALUES("389","core_updater.lock","1633716582","no");
INSERT INTO `lh_options` VALUES("393","dismissed_update_core","a:1:{s:11:\"5.8.1|ru_RU\";b:1;}","no");
INSERT INTO `lh_options` VALUES("394","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.8.1.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.8.1.zip\";s:10:\"no_content\";s:0:\"\";s:11:\"new_bundled\";s:0:\"\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.8.1\";s:7:\"version\";s:5:\"5.8.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1633936746;s:15:\"version_checked\";s:5:\"5.8.1\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `lh_options` VALUES("395","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1633936753;s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:2:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.4.9\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.0\";}s:45:\"enable-svg-webp-ico-upload/itc-svg-upload.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:40:\"w.org/plugins/enable-svg-webp-ico-upload\";s:4:\"slug\";s:26:\"enable-svg-webp-ico-upload\";s:6:\"plugin\";s:45:\"enable-svg-webp-ico-upload/itc-svg-upload.php\";s:11:\"new_version\";s:5:\"1.0.1\";s:3:\"url\";s:57:\"https://wordpress.org/plugins/enable-svg-webp-ico-upload/\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/plugin/enable-svg-webp-ico-upload.1.0.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:79:\"https://ps.w.org/enable-svg-webp-ico-upload/assets/icon-256x256.png?rev=2510822\";s:2:\"1x\";s:79:\"https://ps.w.org/enable-svg-webp-ico-upload/assets/icon-256x256.png?rev=2510822\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:81:\"https://ps.w.org/enable-svg-webp-ico-upload/assets/banner-772x250.png?rev=2510822\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.7\";}}s:7:\"checked\";a:3:{s:34:\"advanced-custom-fields-pro/acf.php\";s:6:\"5.10.2\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.4.9\";s:45:\"enable-svg-webp-ico-upload/itc-svg-upload.php\";s:5:\"1.0.1\";}}","no");
INSERT INTO `lh_options` VALUES("396","_site_transient_update_themes","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1633936750;s:7:\"checked\";a:4:{s:8:\"filhause\";s:5:\"1.0.0\";s:14:\"twentynineteen\";s:3:\"2.1\";s:12:\"twentytwenty\";s:3:\"1.8\";s:15:\"twentytwentyone\";s:3:\"1.4\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:3:{s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"2.1\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.2.1.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.8\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.8.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.4\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.4.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `lh_options` VALUES("442","_site_transient_timeout_available_translations","1633885722","no");
INSERT INTO `lh_options` VALUES("443","_site_transient_available_translations","a:127:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-05-13 15:59:22\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8-beta/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-02 15:48:22\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-08 17:57:56\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-10-29 07:54:22\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.9.18/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-30 20:41:33\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:22:\"Продължение\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"5.4.7\";s:7:\"updated\";s:19:\"2020-10-31 08:48:37\";s:12:\"english_name\";s:20:\"Bengali (Bangladesh)\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.7/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2020-10-30 03:24:38\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8-beta/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-17 13:05:11\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-06 09:17:37\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-13 20:12:59\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-06 13:31:37\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-07 08:20:41\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-10 20:58:55\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.8.1/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-07-22 10:24:20\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-07-22 10:24:47\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/5.8.1/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_AT\";a:8:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-07-10 12:19:50\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-10 20:59:31\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:3:\"dsb\";a:8:{s:8:\"language\";s:3:\"dsb\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-02 11:17:46\";s:12:\"english_name\";s:13:\"Lower Sorbian\";s:11:\"native_name\";s:16:\"Dolnoserbšćina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8.1/dsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"dsb\";i:3;s:3:\"dsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Dalej\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-26 10:54:05\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-25 03:09:33\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-09 10:29:25\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-04 18:08:37\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-25 03:05:46\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-03 10:52:30\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-30 20:54:06\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-04 20:53:18\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_EC\";a:8:{s:8:\"language\";s:5:\"es_EC\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-02 02:19:31\";s:12:\"english_name\";s:17:\"Spanish (Ecuador)\";s:11:\"native_name\";s:19:\"Español de Ecuador\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/es_EC.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-07-30 00:35:05\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-02 20:42:17\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-02 13:13:00\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_DO\";a:8:{s:8:\"language\";s:5:\"es_DO\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-08 14:32:50\";s:12:\"english_name\";s:28:\"Spanish (Dominican Republic)\";s:11:\"native_name\";s:33:\"Español de República Dominicana\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/es_DO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_UY\";a:8:{s:8:\"language\";s:5:\"es_UY\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-03-31 18:33:26\";s:12:\"english_name\";s:17:\"Spanish (Uruguay)\";s:11:\"native_name\";s:19:\"Español de Uruguay\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/es_UY.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-06-14 16:02:22\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PR\";a:8:{s:8:\"language\";s:5:\"es_PR\";s:7:\"version\";s:5:\"5.4.7\";s:7:\"updated\";s:19:\"2020-04-29 15:36:59\";s:12:\"english_name\";s:21:\"Spanish (Puerto Rico)\";s:11:\"native_name\";s:23:\"Español de Puerto Rico\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.7/es_PR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-14 13:29:01\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:6:\"5.2.12\";s:7:\"updated\";s:19:\"2019-03-02 06:35:01\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.2.12/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-14 11:45:58\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-02 02:19:00\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2020-08-12 08:38:59\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8-beta/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-25 08:50:13\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-02 05:28:18\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"fa_AF\";a:8:{s:8:\"language\";s:5:\"fa_AF\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-06-14 12:40:09\";s:12:\"english_name\";s:21:\"Persian (Afghanistan)\";s:11:\"native_name\";s:31:\"(فارسی (افغانستان\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/fa_AF.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-17 11:15:06\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-04 22:43:47\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-08 09:41:41\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-02-22 13:54:46\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-05 22:22:24\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:6:\"4.4.25\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.4.25/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-20 10:01:27\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"להמשיך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"5.4.7\";s:7:\"updated\";s:19:\"2020-11-06 12:34:38\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.7/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-28 10:05:42\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:3:\"hsb\";a:8:{s:8:\"language\";s:3:\"hsb\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-02 11:18:08\";s:12:\"english_name\";s:13:\"Upper Sorbian\";s:11:\"native_name\";s:17:\"Hornjoserbšćina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8.1/hsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"hsb\";i:3;s:3:\"hsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:4:\"Dale\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-04 06:55:18\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Tovább\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-04 18:12:54\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-12-11 10:40:02\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-09 17:15:10\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-10 15:04:23\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-02-16 23:58:56\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nutugne\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-21 06:43:12\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-02 18:03:03\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8.1/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-07-10 11:35:44\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:6:\"5.2.12\";s:7:\"updated\";s:19:\"2019-06-10 16:18:28\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2.12/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:2:\"kn\";a:8:{s:8:\"language\";s:2:\"kn\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-03 06:17:02\";s:12:\"english_name\";s:7:\"Kannada\";s:11:\"native_name\";s:15:\"ಕನ್ನಡ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/kn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kn\";i:2;s:3:\"kan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"ಮುಂದುವರೆಸಿ\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-02 05:27:21\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-07 14:00:59\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8.1/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"ຕໍ່\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-03-23 12:35:40\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-17 20:04:07\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"5.4.7\";s:7:\"updated\";s:19:\"2020-07-01 09:16:57\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-11-22 15:32:08\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-08-31 11:57:07\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.2.30\";s:7:\"updated\";s:19:\"2017-12-26 11:57:10\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.2.30/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ေဆာင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-08 01:47:26\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:6:\"5.2.12\";s:7:\"updated\";s:19:\"2020-05-31 16:07:59\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.2.12/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"जारीराख्नु \";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-01 22:20:58\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.8.1/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-07 19:26:19\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-07 12:56:06\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-03-18 10:59:16\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-08 10:35:11\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.3.26\";s:7:\"updated\";s:19:\"2015-12-02 21:41:29\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.3.26/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"دوام\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-15 08:56:03\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-08 19:39:30\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_AO\";a:8:{s:8:\"language\";s:5:\"pt_AO\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-05-30 09:51:29\";s:12:\"english_name\";s:19:\"Portuguese (Angola)\";s:11:\"native_name\";s:20:\"Português de Angola\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/pt_AO.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-09 21:40:55\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/5.8.1/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-06 17:16:35\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-01 21:02:01\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:3:\"snd\";a:8:{s:8:\"language\";s:3:\"snd\";s:7:\"version\";s:5:\"5.4.7\";s:7:\"updated\";s:19:\"2020-07-07 01:53:37\";s:12:\"english_name\";s:6:\"Sindhi\";s:11:\"native_name\";s:8:\"سنڌي\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.4.7/snd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"sd\";i:2;s:3:\"snd\";i:3;s:3:\"snd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"اڳتي هلو\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-07 12:49:21\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:3:\"skr\";a:8:{s:8:\"language\";s:3:\"skr\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-10 12:52:53\";s:12:\"english_name\";s:7:\"Saraiki\";s:11:\"native_name\";s:14:\"سرائیکی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8.1/skr.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"skr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"جاری رکھو\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-08-31 06:12:58\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Nadaljujte\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-03 10:59:56\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-08-01 21:21:06\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-06 20:34:52\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"sw\";a:8:{s:8:\"language\";s:2:\"sw\";s:7:\"version\";s:5:\"5.3.9\";s:7:\"updated\";s:19:\"2019-10-13 15:35:35\";s:12:\"english_name\";s:7:\"Swahili\";s:11:\"native_name\";s:9:\"Kiswahili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.9/sw.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sw\";i:2;s:3:\"swa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Endelea\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:5:\"ta_LK\";a:8:{s:8:\"language\";s:5:\"ta_LK\";s:7:\"version\";s:6:\"4.2.30\";s:7:\"updated\";s:19:\"2015-12-03 01:07:44\";s:12:\"english_name\";s:17:\"Tamil (Sri Lanka)\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.2.30/ta_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"தொடர்க\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-10 08:48:56\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-09-30 09:04:29\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.17/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-04 12:16:39\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2021-07-03 18:41:33\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-10 12:13:57\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"5.4.7\";s:7:\"updated\";s:19:\"2020-04-09 11:17:33\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.4.7/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-02-28 12:02:22\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-22 14:07:50\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.8.1/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-09-19 06:35:00\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"5.8.1\";s:7:\"updated\";s:19:\"2021-10-08 23:17:35\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8.1/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-06-27 10:46:14\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","no");
INSERT INTO `lh_options` VALUES("452","_transient_timeout_acf_plugin_updates","1634109551","no");
INSERT INTO `lh_options` VALUES("453","_transient_acf_plugin_updates","a:4:{s:7:\"plugins\";a:0:{}s:10:\"expiration\";i:172800;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:6:\"5.10.2\";}}","no");
INSERT INTO `lh_options` VALUES("456","_site_transient_timeout_theme_roots","1633938549","no");
INSERT INTO `lh_options` VALUES("457","_site_transient_theme_roots","a:4:{s:8:\"filhause\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";}","no");
INSERT INTO `lh_options` VALUES("462","_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e","1633979953","no");
INSERT INTO `lh_options` VALUES("463","_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e","a:4:{s:9:\"sandboxed\";b:0;s:5:\"error\";N;s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:3:{i:0;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:65:\"Quiero contribuir al proyecto de WordPress, ¿Por dónde empiezo?\";s:3:\"url\";s:68:\"https://www.meetup.com/learn-wordpress-discussions/events/281200478/\";s:6:\"meetup\";s:27:\"Learn WordPress Discussions\";s:10:\"meetup_url\";s:51:\"https://www.meetup.com/learn-wordpress-discussions/\";s:4:\"date\";s:19:\"2021-10-11 06:00:00\";s:8:\"end_date\";s:19:\"2021-10-11 07:00:00\";s:20:\"start_unix_timestamp\";i:1633957200;s:18:\"end_unix_timestamp\";i:1633960800;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"US\";s:8:\"latitude\";d:37.779998779297;s:9:\"longitude\";d:-122.41999816895;}}i:1;a:10:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:27:\"WordCamp Italia Online 2021\";s:3:\"url\";s:33:\"https://italia.wordcamp.org/2021/\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2021-10-22 14:00:00\";s:8:\"end_date\";s:19:\"2021-10-23 00:00:00\";s:20:\"start_unix_timestamp\";i:1634904000;s:18:\"end_unix_timestamp\";i:1634940000;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"IT\";s:8:\"latitude\";d:41.8725553;s:9:\"longitude\";d:12.516448;}}i:2;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:78:\"WP Moscow #18. Тематический митап про WordPress + Telegram\";s:3:\"url\";s:57:\"https://www.meetup.com/wordpress-moscow/events/281330816/\";s:6:\"meetup\";s:16:\"WordPress Moscow\";s:10:\"meetup_url\";s:40:\"https://www.meetup.com/wordpress-moscow/\";s:4:\"date\";s:19:\"2021-10-21 19:00:00\";s:8:\"end_date\";s:19:\"2021-10-21 21:00:00\";s:20:\"start_unix_timestamp\";i:1634832000;s:18:\"end_unix_timestamp\";i:1634839200;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"RU\";s:8:\"latitude\";d:55.75;s:9:\"longitude\";d:37.619998931885;}}}}","no");
INSERT INTO `lh_options` VALUES("466","_site_transient_timeout_wp_remote_block_patterns_abb70994035adb0d850b14d620e3d9c1","1633940442","no");
INSERT INTO `lh_options` VALUES("467","_site_transient_wp_remote_block_patterns_abb70994035adb0d850b14d620e3d9c1","a:26:{i:0;O:8:\"stdClass\":7:{s:2:\"id\";i:4385;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:103:\"Большой заголовок с выравниванием текста по левому краю\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1273:\"
<div class=\"wp-block-cover alignfull has-background-dim-60 has-background-dim\" style=\"min-height:800px\"><img class=\"wp-block-cover__image-background\" alt=\"\" src=\"https://s.w.org/images/core/5.8/forest.jpg\" data-object-fit=\"cover\" /><div class=\"wp-block-cover__inner-container\">
<h2 class=\"alignwide has-text-color\" style=\"color:#ffe074;font-size:64px\">Лес</h2>



<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\" style=\"flex-basis:55%\">
<div style=\"height:330px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<p class=\"has-text-color\" style=\"color:#ffe074;font-size:12px;line-height:1.3\"><em>Даже ребенок знает, насколько ценен лес. Свежий, захватывающий дух запах деревьев. Эхо птиц, летящих над этой плотной звездой. Стабильный климат, устойчивая разнообразная жизнь и источник культуры. Тем не менее, леса и другие экосистемы висят на волоске и могут превратиться в пахотные земли, пастбища и плантации.</em></p>
</div>



<div class=\"wp-block-column\"></div>
</div>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:73:\"Изображение на обложке с цитатой сверху\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:2:{i:0;s:8:\"featured\";i:1;s:6:\"header\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1864:\"<!-- wp:cover {\"url\":\"https://s.w.org/images/core/5.8/forest.jpg\",\"dimRatio\":60,\"minHeight\":800,\"align\":\"full\"} -->
<div class=\"wp-block-cover alignfull has-background-dim-60 has-background-dim\" style=\"min-height:800px\"><img class=\"wp-block-cover__image-background\" alt=\"\" src=\"https://s.w.org/images/core/5.8/forest.jpg\" data-object-fit=\"cover\" /><div class=\"wp-block-cover__inner-container\"><!-- wp:heading {\"align\":\"wide\",\"style\":{\"color\":{\"text\":\"#ffe074\"},\"typography\":{\"fontSize\":\"64px\"}}} -->
<h2 class=\"alignwide has-text-color\" style=\"color:#ffe074;font-size:64px\">Лес</h2>
<!-- /wp:heading -->

<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"55%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:55%\"><!-- wp:spacer {\"height\":330} -->
<div style=\"height:330px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#ffe074\"},\"typography\":{\"lineHeight\":\"1.3\",\"fontSize\":\"12px\"}}} -->
<p class=\"has-text-color\" style=\"color:#ffe074;font-size:12px;line-height:1.3\"><em>Даже ребенок знает, насколько ценен лес. Свежий, захватывающий дух запах деревьев. Эхо птиц, летящих над этой плотной звездой. Стабильный климат, устойчивая разнообразная жизнь и источник культуры. Тем не менее, леса и другие экосистемы висят на волоске и могут превратиться в пахотные земли, пастбища и плантации.</em></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover -->\";}i:1;O:8:\"stdClass\":7:{s:2:\"id\";i:4384;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:69:\"Большой заголовок с текстом и кнопкой\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1162:\"
<div class=\"wp-block-cover alignfull has-background-dim-40 has-background-dim has-parallax\" style=\"background-image:url(https://s.w.org/images/core/5.8/art-01.jpg);background-color:#000000;min-height:100vh\"><div class=\"wp-block-cover__inner-container\">
<h2 class=\"alignwide has-white-color has-text-color\" style=\"font-size:48px;line-height:1.2\"><strong><em>За границей:</em></strong><br><strong><em>1500–1960</em></strong></h2>



<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\" style=\"flex-basis:60%\">
<p class=\"has-text-color\" style=\"color:#ffffff\">Выставка о различных представлениях океана во времени, между шестнадцатым и двадцатым веками. Проходит в нашей открытой комнате на <em>этаже 2</em>.</p>



<div class=\"wp-block-buttons\">
<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link has-text-color has-background no-border-radius\" style=\"background-color:#000000;color:#ffffff\">Посетить</a></div>
</div>
</div>



<div class=\"wp-block-column\"></div>
</div>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:124:\"Большой заголовок с фоновым изображением, текстом и кнопкой сверху.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:1:{i:0;s:6:\"header\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1972:\"<!-- wp:cover {\"url\":\"https://s.w.org/images/core/5.8/art-01.jpg\",\"hasParallax\":true,\"dimRatio\":40,\"customOverlayColor\":\"#000000\",\"minHeight\":100,\"minHeightUnit\":\"vh\",\"contentPosition\":\"center center\",\"align\":\"full\"} -->
<div class=\"wp-block-cover alignfull has-background-dim-40 has-background-dim has-parallax\" style=\"background-image:url(https://s.w.org/images/core/5.8/art-01.jpg);background-color:#000000;min-height:100vh\"><div class=\"wp-block-cover__inner-container\"><!-- wp:heading {\"style\":{\"typography\":{\"fontSize\":\"48px\",\"lineHeight\":\"1.2\"}},\"className\":\"alignwide has-white-color has-text-color\"} -->
<h2 class=\"alignwide has-white-color has-text-color\" style=\"font-size:48px;line-height:1.2\"><strong><em>За границей:</em></strong><br><strong><em>1500–1960</em></strong></h2>
<!-- /wp:heading -->

<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"60%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:60%\"><!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#ffffff\"}}} -->
<p class=\"has-text-color\" style=\"color:#ffffff\">Выставка о различных представлениях океана во времени, между шестнадцатым и двадцатым веками. Проходит в нашей открытой комнате на <em>этаже 2</em>.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class=\"wp-block-buttons\"><!-- wp:button {\"borderRadius\":0,\"style\":{\"color\":{\"text\":\"#ffffff\",\"background\":\"#000000\"}},\"className\":\"is-style-outline\"} -->
<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link has-text-color has-background no-border-radius\" style=\"background-color:#000000;color:#ffffff\">Посетить</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover -->\";}i:2;O:8:\"stdClass\":7:{s:2:\"id\";i:4395;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:39:\"Два изображения в ряд\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:728:\"
<figure class=\"wp-block-gallery alignwide columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://s.w.org/images/core/5.8/nature-above-01.jpg\" alt=\"Вид с воздуха на волны, разбивающиеся о берег.\" data-full-url=\"https://s.w.org/images/core/5.8/nature-above-01.jpg\" data-link=\"#\" /></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://s.w.org/images/core/5.8/nature-above-02.jpg\" alt=\"Аэрофотоснимок поля. Дорога проходит через правый верхний угол.\" data-full-url=\"https://s.w.org/images/core/5.8/nature-above-02.jpg\" data-link=\"#\" /></figure></li></ul></figure>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:101:\"Галерея изображений с двумя изображениями для примера.\";s:19:\"wpop_viewport_width\";i:800;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:1:{i:0;s:7:\"gallery\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:818:\"<!-- wp:gallery {\"ids\":[null,null],\"linkTo\":\"none\",\"align\":\"wide\"} -->
<figure class=\"wp-block-gallery alignwide columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://s.w.org/images/core/5.8/nature-above-01.jpg\" alt=\"Вид с воздуха на волны, разбивающиеся о берег.\" data-full-url=\"https://s.w.org/images/core/5.8/nature-above-01.jpg\" data-link=\"#\" /></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://s.w.org/images/core/5.8/nature-above-02.jpg\" alt=\"Аэрофотоснимок поля. Дорога проходит через правый верхний угол.\" data-full-url=\"https://s.w.org/images/core/5.8/nature-above-02.jpg\" data-link=\"#\" /></figure></li></ul></figure>
<!-- /wp:gallery -->\";}i:3;O:8:\"stdClass\":7:{s:2:\"id\";i:4380;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:79:\"Два столбца текста со смещенным заголовком\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:2476:\"
<div class=\"wp-container-6163e4b34883e wp-block-group alignfull has-background\" style=\"background-color:#f2f0e9\"><div class=\"wp-block-group__inner-container\">
<div style=\"height:70px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<div class=\"wp-block-columns alignwide are-vertically-aligned-center\">
<div class=\"wp-block-column\" style=\"flex-basis:50%\">
<p class=\"has-text-color\" style=\"color:#000000;font-size:30px;line-height:1.1\"><strong>Океанское вдохновение</strong></p>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:50%\">
<hr class=\"wp-block-separator has-text-color has-background is-style-wide\" style=\"background-color:#000000;color:#000000\" />
</div>
</div>



<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\"></div>



<div class=\"wp-block-column\">
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">Обмотав головы вуалью, женщины вышли на палубу. Теперь они неуклонно двигались вниз по реке, минуя темные силуэты кораблей на якоре, и Лондон представлял собой рой огней с нависшим над ним бледно-желтым куполом. Это были огни больших театров, огни длинных улиц, огни, указывающие на огромные площади домашнего уюта, огни, которые висели высоко в воздухе.</p>
</div>



<div class=\"wp-block-column\">
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">Никакая тьма никогда не осядет на этих светильниках, поскольку никакая тьма не села на них сотни лет. Казалось ужасным, что город вечно пылает на одном и том же месте; ужасен, по крайней мере, для людей, отправляющихся в путешествие по морю и созерцающих его как ограниченный холм, вечно выжженный, вечно покрытый шрамами. С палубы корабля город казался как трусливая фигура, сидячий скряга.</p>
</div>
</div>



<div style=\"height:40px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:80:\"Два столбца текста со смещенным заголовком.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:2:{i:0;s:7:\"columns\";i:1;s:4:\"text\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:3398:\"<!-- wp:group {\"align\":\"full\",\"style\":{\"color\":{\"background\":\"#f2f0e9\"}}} -->
<div class=\"wp-block-group alignfull has-background\" style=\"background-color:#f2f0e9\"><!-- wp:spacer {\"height\":70} -->
<div style=\"height:70px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:columns {\"verticalAlignment\":\"center\",\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide are-vertically-aligned-center\"><!-- wp:column {\"width\":\"50%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:50%\"><!-- wp:paragraph {\"style\":{\"typography\":{\"lineHeight\":\"1.1\",\"fontSize\":\"30px\"},\"color\":{\"text\":\"#000000\"}}} -->
<p class=\"has-text-color\" style=\"color:#000000;font-size:30px;line-height:1.1\"><strong>Океанское вдохновение</strong></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":\"50%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:50%\"><!-- wp:separator {\"customColor\":\"#000000\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator has-text-color has-background is-style-wide\" style=\"background-color:#000000;color:#000000\" />
<!-- /wp:separator --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#000000\"}},\"fontSize\":\"extra-small\"} -->
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">Обмотав головы вуалью, женщины вышли на палубу. Теперь они неуклонно двигались вниз по реке, минуя темные силуэты кораблей на якоре, и Лондон представлял собой рой огней с нависшим над ним бледно-желтым куполом. Это были огни больших театров, огни длинных улиц, огни, указывающие на огромные площади домашнего уюта, огни, которые висели высоко в воздухе.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#000000\"}},\"fontSize\":\"extra-small\"} -->
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">Никакая тьма никогда не осядет на этих светильниках, поскольку никакая тьма не села на них сотни лет. Казалось ужасным, что город вечно пылает на одном и том же месте; ужасен, по крайней мере, для людей, отправляющихся в путешествие по морю и созерцающих его как ограниченный холм, вечно выжженный, вечно покрытый шрамами. С палубы корабля город казался как трусливая фигура, сидячий скряга.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {\"height\":40} -->
<div style=\"height:40px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->\";}i:4;O:8:\"stdClass\":7:{s:2:\"id\";i:4394;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:56:\"Две колонки текста и заголовка\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:2096:\"
<h2 style=\"font-size:38px;line-height:1.4\"><strong>Путешествие началось и началось счастливо с мягкого голубого неба и спокойного моря.</strong></h2>



<div class=\"wp-block-columns\">
<div class=\"wp-block-column\">
<p style=\"font-size:18px\">Они последовали за ней на палубу. Весь дым и дома исчезли, и корабль оказался в открытом море, очень свежем и чистом, хотя и бледном в раннем свете. Они оставили Лондон сидеть в грязи. На горизонте сужалась очень тонкая линия тени, едва достаточная для того, чтобы выдержать бремя Парижа, которое, тем не менее, лежало на нем. Они были свободны от дорог, от человечества, и все они были взволнованы своей свободой.</p>
</div>



<div class=\"wp-block-column\">
<p style=\"font-size:18px\">Корабль неуклонно продвигался сквозь небольшие волны, которые ударили по ней, а затем шипели, как бурлящая вода, оставляя с обеих сторон небольшую границу из пузырьков и пены. Бесцветное октябрьское небо над головой было тонко затянуто облаками, словно шлейфом от костра, а воздух был чудесно соленым и живым. На самом деле было слишком холодно, чтобы стоять на месте. Миссис Эмброуз взяла мужа за руку, и когда они двинулись прочь, по тому, как ее щека повернулась к его щеке, было видно, что у нее есть что сказать личное.</p>
</div>
</div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:94:\"Два столбца текста с длинным заголовком перед ними.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:2:{i:0;s:7:\"columns\";i:1;s:4:\"text\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:2476:\"<!-- wp:heading {\"style\":{\"typography\":{\"fontSize\":38,\"lineHeight\":\"1.4\"}}} -->
<h2 style=\"font-size:38px;line-height:1.4\"><strong>Путешествие началось и началось счастливо с мягкого голубого неба и спокойного моря.</strong></h2>
<!-- /wp:heading -->

<!-- wp:columns -->
<div class=\"wp-block-columns\"><!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":18}}} -->
<p style=\"font-size:18px\">Они последовали за ней на палубу. Весь дым и дома исчезли, и корабль оказался в открытом море, очень свежем и чистом, хотя и бледном в раннем свете. Они оставили Лондон сидеть в грязи. На горизонте сужалась очень тонкая линия тени, едва достаточная для того, чтобы выдержать бремя Парижа, которое, тем не менее, лежало на нем. Они были свободны от дорог, от человечества, и все они были взволнованы своей свободой.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":18}}} -->
<p style=\"font-size:18px\">Корабль неуклонно продвигался сквозь небольшие волны, которые ударили по ней, а затем шипели, как бурлящая вода, оставляя с обеих сторон небольшую границу из пузырьков и пены. Бесцветное октябрьское небо над головой было тонко затянуто облаками, словно шлейфом от костра, а воздух был чудесно соленым и живым. На самом деле было слишком холодно, чтобы стоять на месте. Миссис Эмброуз взяла мужа за руку, и когда они двинулись прочь, по тому, как ее щека повернулась к его щеке, было видно, что у нее есть что сказать личное.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->\";}i:5;O:8:\"stdClass\":7:{s:2:\"id\";i:4387;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:18:\"Заголовок\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:484:\"
<h2 class=\"alignwide\" style=\"font-size:48px;line-height:1.1\">Мы &#8212; студия в Берлине с международной практикой в ​​области архитектуры, городского планирования и дизайна интерьеров. Мы верим в обмен знаниями и продвижение диалога для увеличения творческого потенциала сотрудничества.</h2>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:29:\"Текст заголовка\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:2:{i:0;s:8:\"featured\";i:1;s:4:\"text\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:596:\"<!-- wp:heading {\"align\":\"wide\",\"style\":{\"typography\":{\"fontSize\":\"48px\",\"lineHeight\":\"1.1\"}}} -->
<h2 class=\"alignwide\" style=\"font-size:48px;line-height:1.1\">Мы - студия в Берлине с международной практикой в ​​области архитектуры, городского планирования и дизайна интерьеров. Мы верим в обмен знаниями и продвижение диалога для увеличения творческого потенциала сотрудничества.</h2>
<!-- /wp:heading -->\";}i:6;O:8:\"stdClass\":7:{s:2:\"id\";i:4381;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:77:\"Медиа и текст в полноразмерном контейнере\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1527:\"
<div class=\"wp-block-cover alignfull has-background-dim\" style=\"background-color:#ffffff;min-height:100vh\"><div class=\"wp-block-cover__inner-container\">
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center is-image-fill\" style=\"grid-template-columns:56% auto\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(https://s.w.org/images/core/5.8/soil.jpg);background-position:50% 50%\"><img src=\"https://s.w.org/images/core/5.8/soil.jpg\" alt=\"Крупный план засохшей потрескавшейся земли.\" /></figure><div class=\"wp-block-media-text__content\">
<h2 class=\"has-text-color\" style=\"color:#000000;font-size:32px\"><strong>В чем проблема?</strong></h2>



<p class=\"has-text-color\" style=\"color:#000000;font-size:17px\">Сегодня деревья важнее, чем когда-либо прежде. Сообщается, что из деревьев изготовлено более 10 000 изделий. Посредством химии из скромной поленницы получаются химические вещества, пластмассы и ткани, о которых невозможно было даже представить, когда топор впервые срубил техасское дерево.</p>



<div class=\"wp-block-buttons\">
<div class=\"wp-block-button is-style-fill\"><a class=\"wp-block-button__link\">Узнать больше</a></div>
</div>
</div></div>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:130:\"Медиа и текстовый блок с изображением слева и текстом и кнопкой справа.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:1:{i:0;s:6:\"header\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:2197:\"<!-- wp:cover {\"customOverlayColor\":\"#ffffff\",\"minHeight\":100,\"minHeightUnit\":\"vh\",\"contentPosition\":\"center center\",\"align\":\"full\"} -->
<div class=\"wp-block-cover alignfull has-background-dim\" style=\"background-color:#ffffff;min-height:100vh\"><div class=\"wp-block-cover__inner-container\"><!-- wp:media-text {\"mediaLink\":\"https://s.w.org/images/core/5.8/soil.jpg\",\"mediaType\":\"image\",\"mediaWidth\":56,\"verticalAlignment\":\"center\",\"imageFill\":true} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center is-image-fill\" style=\"grid-template-columns:56% auto\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(https://s.w.org/images/core/5.8/soil.jpg);background-position:50% 50%\"><img src=\"https://s.w.org/images/core/5.8/soil.jpg\" alt=\"Крупный план засохшей потрескавшейся земли.\" /></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"style\":{\"typography\":{\"fontSize\":\"32px\"},\"color\":{\"text\":\"#000000\"}}} -->
<h2 class=\"has-text-color\" style=\"color:#000000;font-size:32px\"><strong>В чем проблема?</strong></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":\"17px\"},\"color\":{\"text\":\"#000000\"}}} -->
<p class=\"has-text-color\" style=\"color:#000000;font-size:17px\">Сегодня деревья важнее, чем когда-либо прежде. Сообщается, что из деревьев изготовлено более 10 000 изделий. Посредством химии из скромной поленницы получаются химические вещества, пластмассы и ткани, о которых невозможно было даже представить, когда топор впервые срубил техасское дерево.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class=\"wp-block-buttons\"><!-- wp:button {\"className\":\"is-style-fill\"} -->
<div class=\"wp-block-button is-style-fill\"><a class=\"wp-block-button__link\">Узнать больше</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:media-text --></div></div>
<!-- /wp:cover -->\";}i:7;O:8:\"stdClass\":7:{s:2:\"id\";i:4383;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:63:\"Медиа и текст с изображением слева\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:644:\"
<div class=\"wp-block-media-text alignfull is-stacked-on-mobile is-vertically-aligned-center\"><figure class=\"wp-block-media-text__media\"><img src=\"https://s.w.org/images/core/5.8/architecture-04.jpg\" alt=\"Крупный план, абстрактный вид архитектуры.\" /></figure><div class=\"wp-block-media-text__content\">
<h3 class=\"has-text-align-center has-text-color\" style=\"color:#000000\"><strong>Открытые пространства</strong></h3>



<p class=\"has-text-align-center has-extra-small-font-size\"><a href=\"#\">Посмотрите тематическое исследование ↗</a></p>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:112:\"Медиа и текстовый блок с изображением слева и текстом справа.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:2:{i:0;s:8:\"featured\";i:1;s:6:\"header\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:951:\"<!-- wp:media-text {\"align\":\"full\",\"mediaType\":\"image\",\"verticalAlignment\":\"center\"} -->
<div class=\"wp-block-media-text alignfull is-stacked-on-mobile is-vertically-aligned-center\"><figure class=\"wp-block-media-text__media\"><img src=\"https://s.w.org/images/core/5.8/architecture-04.jpg\" alt=\"Крупный план, абстрактный вид архитектуры.\" /></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"textAlign\":\"center\",\"level\":3,\"style\":{\"color\":{\"text\":\"#000000\"}}} -->
<h3 class=\"has-text-align-center has-text-color\" style=\"color:#000000\"><strong>Открытые пространства</strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {\"align\":\"center\",\"fontSize\":\"extra-small\"} -->
<p class=\"has-text-align-center has-extra-small-font-size\"><a href=\"#\">Посмотрите тематическое исследование ↗</a></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->\";}i:8;O:8:\"stdClass\":7:{s:2:\"id\";i:4382;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:65:\"Медиа и текст с изображением справа\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:830:\"
<div class=\"wp-block-media-text alignfull has-media-on-the-right is-stacked-on-mobile is-vertically-aligned-center is-style-default\" style=\"grid-template-columns:auto 56%\"><figure class=\"wp-block-media-text__media\"><img src=\"https://s.w.org/images/core/5.8/art-02.jpg\" alt=\"Зелено-коричневый сельский пейзаж, ведущий в ярко-синий океан и слегка облачное небо, выполненный масляными красками.\" /></figure><div class=\"wp-block-media-text__content\">
<h2 class=\"has-text-color\" style=\"color:#000000\"><strong>Берег синего моря</strong></h2>



<p class=\"has-text-color\" style=\"color:#636363;font-size:17px;line-height:1.1\">Элеонора Харрис&nbsp;(Американка, 1901-1942)</p>
</div></div>



<p></p>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:112:\"Медиа и текстовый блок с изображением справа и текстом слева.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:1:{i:0;s:6:\"header\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1283:\"<!-- wp:media-text {\"align\":\"full\",\"mediaPosition\":\"right\",\"mediaLink\":\"#\",\"mediaType\":\"image\",\"mediaWidth\":56,\"verticalAlignment\":\"center\",\"className\":\"is-style-default\"} -->
<div class=\"wp-block-media-text alignfull has-media-on-the-right is-stacked-on-mobile is-vertically-aligned-center is-style-default\" style=\"grid-template-columns:auto 56%\"><figure class=\"wp-block-media-text__media\"><img src=\"https://s.w.org/images/core/5.8/art-02.jpg\" alt=\"Зелено-коричневый сельский пейзаж, ведущий в ярко-синий океан и слегка облачное небо, выполненный масляными красками.\" /></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"style\":{\"color\":{\"text\":\"#000000\"}}} -->
<h2 class=\"has-text-color\" style=\"color:#000000\"><strong>Берег синего моря</strong></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"lineHeight\":\"1.1\",\"fontSize\":\"17px\"},\"color\":{\"text\":\"#636363\"}}} -->
<p class=\"has-text-color\" style=\"color:#636363;font-size:17px;line-height:1.1\">Элеонора Харрис&nbsp;(Американка, 1901-1942)</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->\";}i:9;O:8:\"stdClass\":7:{s:2:\"id\";i:4379;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:69:\"Три колонки с изображениями и текстом\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:3405:\"
<div class=\"wp-container-6163e4b34cfca wp-block-group alignfull has-background\" style=\"background-color:#f8f4e4\"><div class=\"wp-block-group__inner-container\">
<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\">
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<h6 class=\"has-text-color\" style=\"color:#000000\">ЭКОСИСТЕМА</h6>



<p class=\"has-text-color\" style=\"color:#000000;font-size:5vw;line-height:1.1\"><strong>Положительный рост.</strong></p>



<div style=\"height:5px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
</div>
</div>



<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\" style=\"flex-basis:33.38%\">
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\"><em>Природа</em> в обычном смысле слова относится к сущностям, неизменным человеком; космос, воздух, река, лист. <em>Искусство</em> применяется к смеси его воли с теми же вещами, как в доме, канале, статуе, картине. Но его операции, взятые вместе, настолько незначительны, это небольшое измельчение, выпечка, заплатка и стирка, что в таком грандиозном впечатлении, как мир, в человеческом сознании, они не меняют результата.</p>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:33%\">
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-01.jpg\" alt=\"Солнце садится сквозь густой лес деревьев.\" /></figure>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:33.62%\">
<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-02.jpg\" alt=\"Ветровые турбины, стоящие на травянистой равнине, против голубого неба\" /></figure>
</div>
</div>



<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\" style=\"flex-basis:67%\">
<div class=\"wp-block-image\"><figure class=\"alignright size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-03.jpg\" alt=\"Солнце светит над гребнем, спускающимся к берегу. Вдалеке по дороге едет машина.\" /></figure></div>
</div>



<div class=\"wp-block-column is-vertically-aligned-center\" style=\"flex-basis:33%\">
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">Несомненно, у нас нет вопросов, на которые невозможно ответить. Мы должны доверять совершенству творения настолько, чтобы верить в то, что какое бы любопытство ни пробудил в наших умах порядок вещей, порядок вещей может удовлетворить. Состояние каждого человека &#8212; это иероглифическое решение тех вопросов, которые он задавал.</p>
</div>
</div>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:142:\"Три столбца с изображениями и текстом с интервалом по вертикали для смещения.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:2:{i:0;s:7:\"columns\";i:1;s:8:\"featured\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:4739:\"<!-- wp:group {\"align\":\"full\",\"style\":{\"color\":{\"background\":\"#f8f4e4\"}}} -->
<div class=\"wp-block-group alignfull has-background\" style=\"background-color:#f8f4e4\"><!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:spacer -->
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:heading {\"level\":6,\"style\":{\"color\":{\"text\":\"#000000\"}}} -->
<h6 class=\"has-text-color\" style=\"color:#000000\">ЭКОСИСТЕМА</h6>
<!-- /wp:heading -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"lineHeight\":\"1.1\",\"fontSize\":\"5vw\"},\"color\":{\"text\":\"#000000\"}}} -->
<p class=\"has-text-color\" style=\"color:#000000;font-size:5vw;line-height:1.1\"><strong>Положительный рост.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:spacer {\"height\":5} -->
<div style=\"height:5px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"33.38%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:33.38%\"><!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#000000\"}},\"fontSize\":\"extra-small\"} -->
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\"><em>Природа</em> в обычном смысле слова относится к сущностям, неизменным человеком; космос, воздух, река, лист. <em>Искусство</em> применяется к смеси его воли с теми же вещами, как в доме, канале, статуе, картине. Но его операции, взятые вместе, настолько незначительны, это небольшое измельчение, выпечка, заплатка и стирка, что в таком грандиозном впечатлении, как мир, в человеческом сознании, они не меняют результата.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":\"33%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:33%\"><!-- wp:spacer -->
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-01.jpg\" alt=\"Солнце садится сквозь густой лес деревьев.\" /></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":\"33.62%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:33.62%\"><!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-02.jpg\" alt=\"Ветровые турбины, стоящие на травянистой равнине, против голубого неба\" /></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"67%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:67%\"><!-- wp:image {\"align\":\"right\",\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<div class=\"wp-block-image\"><figure class=\"alignright size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-03.jpg\" alt=\"Солнце светит над гребнем, спускающимся к берегу. Вдалеке по дороге едет машина.\" /></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"verticalAlignment\":\"center\",\"width\":\"33%\"} -->
<div class=\"wp-block-column is-vertically-aligned-center\" style=\"flex-basis:33%\"><!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#000000\"}},\"fontSize\":\"extra-small\"} -->
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">Несомненно, у нас нет вопросов, на которые невозможно ответить. Мы должны доверять совершенству творения настолько, чтобы верить в то, что какое бы любопытство ни пробудил в наших умах порядок вещей, порядок вещей может удовлетворить. Состояние каждого человека - это иероглифическое решение тех вопросов, которые он задавал.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->\";}i:10;O:8:\"stdClass\":7:{s:2:\"id\";i:4377;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:74:\"Три колонки со смещенными изображениями\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1222:\"
<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\" style=\"flex-basis:25%\">
<figure class=\"wp-block-image size-large is-style-default\"><img src=\"https://s.w.org/images/core/5.8/architecture-01.jpg\" alt=\"Крупный план, абстрактный вид геометрической архитектуры.\" /></figure>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:25%\">
<div style=\"height:500px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<div style=\"height:150px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/architecture-02.jpg\" alt=\"Крупным планом вид окна белого здания под углом.\" /></figure>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:45%\">
<figure class=\"wp-block-image size-large is-style-default\"><img src=\"https://s.w.org/images/core/5.8/architecture-03.jpg\" alt=\"Крупный план угла белого геометрического здания с острыми и скругленными углами.\" /></figure>



<div style=\"height:285px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
</div>
</div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:75:\"Три колонки со смещенными изображениями.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:2:{i:0;s:7:\"gallery\";i:1;s:6:\"images\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1898:\"<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"25%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:25%\"><!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\",\"className\":\"is-style-default\"} -->
<figure class=\"wp-block-image size-large is-style-default\"><img src=\"https://s.w.org/images/core/5.8/architecture-01.jpg\" alt=\"Крупный план, абстрактный вид геометрической архитектуры.\" /></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":\"25%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:25%\"><!-- wp:spacer {\"height\":500} -->
<div style=\"height:500px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:spacer {\"height\":150} -->
<div style=\"height:150px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/architecture-02.jpg\" alt=\"Крупным планом вид окна белого здания под углом.\" /></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":\"45%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:45%\"><!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\",\"className\":\"is-style-default\"} -->
<figure class=\"wp-block-image size-large is-style-default\"><img src=\"https://s.w.org/images/core/5.8/architecture-03.jpg\" alt=\"Крупный план угла белого геометрического здания с острыми и скругленными углами.\" /></figure>
<!-- /wp:image -->

<!-- wp:spacer {\"height\":285} -->
<div style=\"height:285px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->\";}i:11;O:8:\"stdClass\":7:{s:2:\"id\";i:4378;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:34:\"Три колонки текста\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1041:\"
<div class=\"wp-block-columns alignfull has-text-color has-background\" style=\"background-color:#ffffff;color:#000000\">
<div class=\"wp-block-column\">
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"http://wordpress.org\">Виртуальный тур ↗</a></strong></h3>



<p>Примите участие в виртуальной экскурсии по музею. Идеально подходит для школ и мероприятий.</p>
</div>



<div class=\"wp-block-column\">
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"https://wordpress.org\">Текущие шоу ↗</a></strong></h3>



<p>Будьте в курсе и смотрите наши текущие выставки здесь.</p>
</div>



<div class=\"wp-block-column\">
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"https://wordpress.org\">Полезная информация ↗</a></strong></h3>



<p>Узнайте о времени работы, ценах на билеты и скидках.</p>
</div>
</div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:35:\"Три колонки текста.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:3:{i:0;s:7:\"columns\";i:1;s:8:\"featured\";i:2;s:4:\"text\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1736:\"<!-- wp:columns {\"align\":\"full\",\"style\":{\"color\":{\"text\":\"#000000\",\"background\":\"#ffffff\"}}} -->
<div class=\"wp-block-columns alignfull has-text-color has-background\" style=\"background-color:#ffffff;color:#000000\"><!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:heading {\"level\":3,\"style\":{\"typography\":{\"fontSize\":\"24px\",\"lineHeight\":\"1.3\"}}} -->
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"http://wordpress.org\">Виртуальный тур ↗</a></strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Примите участие в виртуальной экскурсии по музею. Идеально подходит для школ и мероприятий.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:heading {\"level\":3,\"style\":{\"typography\":{\"fontSize\":\"24px\",\"lineHeight\":\"1.3\"}}} -->
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"https://wordpress.org\">Текущие шоу ↗</a></strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Будьте в курсе и смотрите наши текущие выставки здесь.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:heading {\"level\":3,\"style\":{\"typography\":{\"fontSize\":\"24px\",\"lineHeight\":\"1.3\"}}} -->
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"https://wordpress.org\">Полезная информация ↗</a></strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Узнайте о времени работы, ценах на билеты и скидках.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->\";}i:12;O:8:\"stdClass\":7:{s:2:\"id\";i:4391;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:12:\"Цитата\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:771:\"
<hr class=\"wp-block-separator is-style-default\" />



<div class=\"wp-block-image is-style-rounded\"><figure class=\"aligncenter size-large is-resized\"><img loading=\"lazy\" src=\"https://s.w.org/images/core/5.8/portrait.jpg\" alt=\"Боковой профиль женщины в коричневой водолазке и белой сумке. Она смотрит с закрытыми глазами.\" width=\"150\" height=\"150\" /></figure></div>



<blockquote class=\"wp-block-quote has-text-align-center is-style-large\"><p>«Участие заставляет меня чувствовать, что я полезен планете».</p><cite>&#8212; Анна Вонг,<em>Волонтер</em></cite></blockquote>



<hr class=\"wp-block-separator is-style-default\" />
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:0:\"\";s:19:\"wpop_viewport_width\";i:800;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"ru_RU\";}s:14:\"category_slugs\";a:1:{i:0;s:4:\"text\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1139:\"<!-- wp:separator {\"className\":\"is-style-default\"} -->
<hr class=\"wp-block-separator is-style-default\" />
<!-- /wp:separator -->

<!-- wp:image {\"align\":\"center\",\"width\":150,\"height\":150,\"sizeSlug\":\"large\",\"linkDestination\":\"none\",\"className\":\"is-style-rounded\"} -->
<div class=\"wp-block-image is-style-rounded\"><figure class=\"aligncenter size-large is-resized\"><img src=\"https://s.w.org/images/core/5.8/portrait.jpg\" alt=\"Боковой профиль женщины в коричневой водолазке и белой сумке. Она смотрит с закрытыми глазами.\" width=\"150\" height=\"150\" /></figure></div>
<!-- /wp:image -->

<!-- wp:quote {\"align\":\"center\",\"className\":\"is-style-large\"} -->
<blockquote class=\"wp-block-quote has-text-align-center is-style-large\"><p>«Участие заставляет меня чувствовать, что я полезен планете».</p><cite>- Анна Вонг,<em>Волонтер</em></cite></blockquote>
<!-- /wp:quote -->

<!-- wp:separator {\"className\":\"is-style-default\"} -->
<hr class=\"wp-block-separator is-style-default\" />
<!-- /wp:separator -->\";}i:13;O:8:\"stdClass\":7:{s:2:\"id\";i:184;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:7:\"Heading\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:290:\"
<h2 class=\"alignwide\" style=\"font-size:48px;line-height:1.1\">We&#8217;re a studio in Berlin with an international practice in architecture, urban planning and interior design. We believe in sharing knowledge and promoting dialogue to increase the creative potential of collaboration.</h2>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:12:\"Heading text\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:1:{i:0;s:12:\"core/heading\";}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:2:{i:0;s:8:\"featured\";i:1;s:4:\"text\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:402:\"<!-- wp:heading {\"align\":\"wide\",\"style\":{\"typography\":{\"fontSize\":\"48px\",\"lineHeight\":\"1.1\"}}} -->
<h2 class=\"alignwide\" style=\"font-size:48px;line-height:1.1\">We\'re a studio in Berlin with an international practice in architecture, urban planning and interior design. We believe in sharing knowledge and promoting dialogue to increase the creative potential of collaboration.</h2>
<!-- /wp:heading -->\";}i:14;O:8:\"stdClass\":7:{s:2:\"id\";i:185;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:35:\"Large header with left-aligned text\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1019:\"
<div class=\"wp-block-cover alignfull has-background-dim-60 has-background-dim\" style=\"min-height:800px\"><img class=\"wp-block-cover__image-background\" alt=\"\" src=\"https://s.w.org/images/core/5.8/forest.jpg\" data-object-fit=\"cover\" /><div class=\"wp-block-cover__inner-container\">
<h2 class=\"alignwide has-text-color\" style=\"color:#ffe074;font-size:64px\">Forest.</h2>



<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\" style=\"flex-basis:55%\">
<div style=\"height:330px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<p class=\"has-text-color\" style=\"color:#ffe074;font-size:12px;line-height:1.3\"><em>Even a child knows how valuable the forest is. The fresh, breathtaking smell of trees. Echoing birds flying above that dense magnitude. A stable climate, a sustainable diverse life and a source of culture. Yet, forests and other ecosystems hang in the balance, threatened to become croplands, pasture, and plantations.</em></p>
</div>



<div class=\"wp-block-column\"></div>
</div>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:29:\"Cover image with quote on top\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:2:{i:0;s:8:\"featured\";i:1;s:6:\"header\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1610:\"<!-- wp:cover {\"url\":\"https://s.w.org/images/core/5.8/forest.jpg\",\"dimRatio\":60,\"minHeight\":800,\"align\":\"full\"} -->
<div class=\"wp-block-cover alignfull has-background-dim-60 has-background-dim\" style=\"min-height:800px\"><img class=\"wp-block-cover__image-background\" alt=\"\" src=\"https://s.w.org/images/core/5.8/forest.jpg\" data-object-fit=\"cover\" /><div class=\"wp-block-cover__inner-container\"><!-- wp:heading {\"align\":\"wide\",\"style\":{\"color\":{\"text\":\"#ffe074\"},\"typography\":{\"fontSize\":\"64px\"}}} -->
<h2 class=\"alignwide has-text-color\" style=\"color:#ffe074;font-size:64px\">Forest.</h2>
<!-- /wp:heading -->

<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"55%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:55%\"><!-- wp:spacer {\"height\":330} -->
<div style=\"height:330px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#ffe074\"},\"typography\":{\"lineHeight\":\"1.3\",\"fontSize\":\"12px\"}}} -->
<p class=\"has-text-color\" style=\"color:#ffe074;font-size:12px;line-height:1.3\"><em>Even a child knows how valuable the forest is. The fresh, breathtaking smell of trees. Echoing birds flying above that dense magnitude. A stable climate, a sustainable diverse life and a source of culture. Yet, forests and other ecosystems hang in the balance, threatened to become croplands, pasture, and plantations.</em></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover -->\";}i:15;O:8:\"stdClass\":7:{s:2:\"id\";i:186;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:35:\"Large header with text and a button\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1055:\"
<div class=\"wp-block-cover alignfull has-background-dim-40 has-background-dim has-parallax\" style=\"background-image:url(https://s.w.org/images/core/5.8/art-01.jpg);background-color:#000000;min-height:100vh\"><div class=\"wp-block-cover__inner-container\">
<h2 class=\"alignwide has-white-color has-text-color\" style=\"font-size:48px;line-height:1.2\"><strong><em>Overseas:</em></strong><br><strong><em>1500 — 1960</em></strong></h2>



<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\" style=\"flex-basis:60%\">
<p class=\"has-text-color\" style=\"color:#ffffff\">An exhibition about the different representations of the ocean throughout time, between the sixteenth and the twentieth century. Taking place in our Open Room in <em>Floor 2</em>.</p>



<div class=\"wp-block-buttons\">
<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link has-text-color has-background no-border-radius\" style=\"background-color:#000000;color:#ffffff\">Visit</a></div>
</div>
</div>



<div class=\"wp-block-column\"></div>
</div>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:62:\"Large header with background image and text and button on top.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:1:{i:0;s:6:\"header\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1865:\"<!-- wp:cover {\"url\":\"https://s.w.org/images/core/5.8/art-01.jpg\",\"hasParallax\":true,\"dimRatio\":40,\"customOverlayColor\":\"#000000\",\"minHeight\":100,\"minHeightUnit\":\"vh\",\"contentPosition\":\"center center\",\"align\":\"full\"} -->
<div class=\"wp-block-cover alignfull has-background-dim-40 has-background-dim has-parallax\" style=\"background-image:url(https://s.w.org/images/core/5.8/art-01.jpg);background-color:#000000;min-height:100vh\"><div class=\"wp-block-cover__inner-container\"><!-- wp:heading {\"style\":{\"typography\":{\"fontSize\":\"48px\",\"lineHeight\":\"1.2\"}},\"className\":\"alignwide has-white-color has-text-color\"} -->
<h2 class=\"alignwide has-white-color has-text-color\" style=\"font-size:48px;line-height:1.2\"><strong><em>Overseas:</em></strong><br><strong><em>1500 — 1960</em></strong></h2>
<!-- /wp:heading -->

<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"60%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:60%\"><!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#ffffff\"}}} -->
<p class=\"has-text-color\" style=\"color:#ffffff\">An exhibition about the different representations of the ocean throughout time, between the sixteenth and the twentieth century. Taking place in our Open Room in <em>Floor 2</em>.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class=\"wp-block-buttons\"><!-- wp:button {\"borderRadius\":0,\"style\":{\"color\":{\"text\":\"#ffffff\",\"background\":\"#000000\"}},\"className\":\"is-style-outline\"} -->
<div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link has-text-color has-background no-border-radius\" style=\"background-color:#000000;color:#ffffff\">Visit</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover -->\";}i:16;O:8:\"stdClass\":7:{s:2:\"id\";i:196;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:41:\"Media and text in a full height container\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1194:\"
<div class=\"wp-block-cover alignfull has-background-dim\" style=\"background-color:#ffffff;min-height:100vh\"><div class=\"wp-block-cover__inner-container\">
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center is-image-fill\" style=\"grid-template-columns:56% auto\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(https://s.w.org/images/core/5.8/soil.jpg);background-position:50% 50%\"><img src=\"https://s.w.org/images/core/5.8/soil.jpg\" alt=\"Close-up of dried, cracked earth.\" /></figure><div class=\"wp-block-media-text__content\">
<h2 class=\"has-text-color\" style=\"color:#000000;font-size:32px\"><strong>What&#8217;s the problem?</strong></h2>



<p class=\"has-text-color\" style=\"color:#000000;font-size:17px\">Trees are more important today than ever before. More than 10,000 products are reportedly made from trees. Through chemistry, the humble woodpile is yielding chemicals, plastics and fabrics that were beyond comprehension when an axe first felled a Texas tree.</p>



<div class=\"wp-block-buttons\">
<div class=\"wp-block-button is-style-fill\"><a class=\"wp-block-button__link\">Learn more</a></div>
</div>
</div></div>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:77:\"Media and text block with image to the left and text and button to the right.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:1:{i:0;s:6:\"header\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1858:\"<!-- wp:cover {\"customOverlayColor\":\"#ffffff\",\"minHeight\":100,\"minHeightUnit\":\"vh\",\"contentPosition\":\"center center\",\"align\":\"full\"} -->
<div class=\"wp-block-cover alignfull has-background-dim\" style=\"background-color:#ffffff;min-height:100vh\"><div class=\"wp-block-cover__inner-container\"><!-- wp:media-text {\"mediaLink\":\"https://s.w.org/images/core/5.8/soil.jpg\",\"mediaType\":\"image\",\"mediaWidth\":56,\"verticalAlignment\":\"center\",\"imageFill\":true} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center is-image-fill\" style=\"grid-template-columns:56% auto\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(https://s.w.org/images/core/5.8/soil.jpg);background-position:50% 50%\"><img src=\"https://s.w.org/images/core/5.8/soil.jpg\" alt=\"Close-up of dried, cracked earth.\" /></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"style\":{\"typography\":{\"fontSize\":\"32px\"},\"color\":{\"text\":\"#000000\"}}} -->
<h2 class=\"has-text-color\" style=\"color:#000000;font-size:32px\"><strong>What\'s the problem?</strong></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":\"17px\"},\"color\":{\"text\":\"#000000\"}}} -->
<p class=\"has-text-color\" style=\"color:#000000;font-size:17px\">Trees are more important today than ever before. More than 10,000 products are reportedly made from trees. Through chemistry, the humble woodpile is yielding chemicals, plastics and fabrics that were beyond comprehension when an axe first felled a Texas tree.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class=\"wp-block-buttons\"><!-- wp:button {\"className\":\"is-style-fill\"} -->
<div class=\"wp-block-button is-style-fill\"><a class=\"wp-block-button__link\">Learn more</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:media-text --></div></div>
<!-- /wp:cover -->\";}i:17;O:8:\"stdClass\":7:{s:2:\"id\";i:192;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:37:\"Media and text with image on the left\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:520:\"
<div class=\"wp-block-media-text alignfull is-stacked-on-mobile is-vertically-aligned-center\"><figure class=\"wp-block-media-text__media\"><img src=\"https://s.w.org/images/core/5.8/architecture-04.jpg\" alt=\"Close-up, abstract view of architecture.\" /></figure><div class=\"wp-block-media-text__content\">
<h3 class=\"has-text-align-center has-text-color\" style=\"color:#000000\"><strong>Open Spaces</strong></h3>



<p class=\"has-text-align-center has-extra-small-font-size\"><a href=\"#\">See case study ↗</a></p>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:66:\"Media and text block with image to the left and text to the right.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:2:{i:0;s:8:\"featured\";i:1;s:6:\"header\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:827:\"<!-- wp:media-text {\"align\":\"full\",\"mediaType\":\"image\",\"verticalAlignment\":\"center\"} -->
<div class=\"wp-block-media-text alignfull is-stacked-on-mobile is-vertically-aligned-center\"><figure class=\"wp-block-media-text__media\"><img src=\"https://s.w.org/images/core/5.8/architecture-04.jpg\" alt=\"Close-up, abstract view of architecture.\" /></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"textAlign\":\"center\",\"level\":3,\"style\":{\"color\":{\"text\":\"#000000\"}}} -->
<h3 class=\"has-text-align-center has-text-color\" style=\"color:#000000\"><strong>Open Spaces</strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {\"align\":\"center\",\"fontSize\":\"extra-small\"} -->
<p class=\"has-text-align-center has-extra-small-font-size\"><a href=\"#\">See case study ↗</a></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->\";}i:18;O:8:\"stdClass\":7:{s:2:\"id\";i:195;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:38:\"Media and text with image on the right\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:685:\"
<div class=\"wp-block-media-text alignfull has-media-on-the-right is-stacked-on-mobile is-vertically-aligned-center is-style-default\" style=\"grid-template-columns:auto 56%\"><figure class=\"wp-block-media-text__media\"><img src=\"https://s.w.org/images/core/5.8/art-02.jpg\" alt=\"A green and brown rural landscape leading into a bright blue ocean and slightly cloudy sky, done in oil paints.\" /></figure><div class=\"wp-block-media-text__content\">
<h2 class=\"has-text-color\" style=\"color:#000000\"><strong>Shore with Blue Sea</strong></h2>



<p class=\"has-text-color\" style=\"color:#636363;font-size:17px;line-height:1.1\">Eleanor Harris&nbsp;(American, 1901-1942)</p>
</div></div>



<p></p>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:66:\"Media and text block with image to the right and text to the left.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:1:{i:0;s:6:\"header\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1138:\"<!-- wp:media-text {\"align\":\"full\",\"mediaPosition\":\"right\",\"mediaLink\":\"#\",\"mediaType\":\"image\",\"mediaWidth\":56,\"verticalAlignment\":\"center\",\"className\":\"is-style-default\"} -->
<div class=\"wp-block-media-text alignfull has-media-on-the-right is-stacked-on-mobile is-vertically-aligned-center is-style-default\" style=\"grid-template-columns:auto 56%\"><figure class=\"wp-block-media-text__media\"><img src=\"https://s.w.org/images/core/5.8/art-02.jpg\" alt=\"A green and brown rural landscape leading into a bright blue ocean and slightly cloudy sky, done in oil paints.\" /></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"style\":{\"color\":{\"text\":\"#000000\"}}} -->
<h2 class=\"has-text-color\" style=\"color:#000000\"><strong>Shore with Blue Sea</strong></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"lineHeight\":\"1.1\",\"fontSize\":\"17px\"},\"color\":{\"text\":\"#636363\"}}} -->
<p class=\"has-text-color\" style=\"color:#636363;font-size:17px;line-height:1.1\">Eleanor Harris&nbsp;(American, 1901-1942)</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->\";}i:19;O:8:\"stdClass\":7:{s:2:\"id\";i:27;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:5:\"Quote\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:654:\"
<hr class=\"wp-block-separator is-style-default\" />



<div class=\"wp-block-image is-style-rounded\"><figure class=\"aligncenter size-large is-resized\"><img loading=\"lazy\" src=\"https://s.w.org/images/core/5.8/portrait.jpg\" alt=\"A side profile of a woman in a russet-colored turtleneck and white bag. She looks up with her eyes closed.\" width=\"150\" height=\"150\" /></figure></div>



<blockquote class=\"wp-block-quote has-text-align-center is-style-large\"><p>&#171;Contributing makes me feel like I&#8217;m being useful to the planet.&#187;</p><cite>— Anna Wong, <em>Volunteer</em></cite></blockquote>



<hr class=\"wp-block-separator is-style-default\" />
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:0:\"\";s:19:\"wpop_viewport_width\";i:800;s:16:\"wpop_block_types\";a:1:{i:0;s:10:\"core/quote\";}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:1:{i:0;s:4:\"text\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1012:\"<!-- wp:separator {\"className\":\"is-style-default\"} -->
<hr class=\"wp-block-separator is-style-default\" />
<!-- /wp:separator -->

<!-- wp:image {\"align\":\"center\",\"width\":150,\"height\":150,\"sizeSlug\":\"large\",\"linkDestination\":\"none\",\"className\":\"is-style-rounded\"} -->
<div class=\"wp-block-image is-style-rounded\"><figure class=\"aligncenter size-large is-resized\"><img src=\"https://s.w.org/images/core/5.8/portrait.jpg\" alt=\"A side profile of a woman in a russet-colored turtleneck and white bag. She looks up with her eyes closed.\" width=\"150\" height=\"150\" /></figure></div>
<!-- /wp:image -->

<!-- wp:quote {\"align\":\"center\",\"className\":\"is-style-large\"} -->
<blockquote class=\"wp-block-quote has-text-align-center is-style-large\"><p>\"Contributing makes me feel like I\'m being useful to the planet.\"</p><cite>— Anna Wong, <em>Volunteer</em></cite></blockquote>
<!-- /wp:quote -->

<!-- wp:separator {\"className\":\"is-style-default\"} -->
<hr class=\"wp-block-separator is-style-default\" />
<!-- /wp:separator -->\";}i:20;O:8:\"stdClass\":7:{s:2:\"id\";i:200;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:21:\"Three columns of text\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:801:\"
<div class=\"wp-block-columns alignfull has-text-color has-background\" style=\"background-color:#ffffff;color:#000000\">
<div class=\"wp-block-column\">
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"http://wordpress.org\">Virtual Tour ↗</a></strong></h3>



<p>Get a virtual tour of the museum. Ideal for schools and events.</p>
</div>



<div class=\"wp-block-column\">
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"https://wordpress.org\">Current Shows ↗</a></strong></h3>



<p>Stay updated and see our current exhibitions here.</p>
</div>



<div class=\"wp-block-column\">
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"https://wordpress.org\">Useful Info ↗</a></strong></h3>



<p>Get to know our opening times, ticket prices and discounts.</p>
</div>
</div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:22:\"Three columns of text.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:3:{i:0;s:7:\"columns\";i:1;s:8:\"featured\";i:2;s:4:\"text\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1496:\"<!-- wp:columns {\"align\":\"full\",\"style\":{\"color\":{\"text\":\"#000000\",\"background\":\"#ffffff\"}}} -->
<div class=\"wp-block-columns alignfull has-text-color has-background\" style=\"background-color:#ffffff;color:#000000\"><!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:heading {\"level\":3,\"style\":{\"typography\":{\"fontSize\":\"24px\",\"lineHeight\":\"1.3\"}}} -->
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"http://wordpress.org\">Virtual Tour ↗</a></strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Get a virtual tour of the museum. Ideal for schools and events.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:heading {\"level\":3,\"style\":{\"typography\":{\"fontSize\":\"24px\",\"lineHeight\":\"1.3\"}}} -->
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"https://wordpress.org\">Current Shows ↗</a></strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Stay updated and see our current exhibitions here.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:heading {\"level\":3,\"style\":{\"typography\":{\"fontSize\":\"24px\",\"lineHeight\":\"1.3\"}}} -->
<h3 style=\"font-size:24px;line-height:1.3\"><strong><a href=\"https://wordpress.org\">Useful Info ↗</a></strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Get to know our opening times, ticket prices and discounts.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->\";}i:21;O:8:\"stdClass\":7:{s:2:\"id\";i:199;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:34:\"Three columns with images and text\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:2646:\"
<div class=\"wp-container-6163e4b356661 wp-block-group alignfull has-background\" style=\"background-color:#f8f4e4\"><div class=\"wp-block-group__inner-container\">
<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\">
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<h6 class=\"has-text-color\" style=\"color:#000000\">ECOSYSTEM</h6>



<p class=\"has-text-color\" style=\"color:#000000;font-size:5vw;line-height:1.1\"><strong>Positive growth.</strong></p>



<div style=\"height:5px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
</div>
</div>



<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\" style=\"flex-basis:33.38%\">
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\"><em>Nature</em>, in the common sense, refers to essences unchanged by man; space, the air, the river, the leaf.&nbsp;<em>Art</em>&nbsp;is applied to the mixture of his will with the same things, as in a house, a canal, a statue, a picture. But his operations taken together are so insignificant, a little chipping, baking, patching, and washing, that in an impression so grand as that of the world on the human mind, they do not vary the result.</p>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:33%\">
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-01.jpg\" alt=\"The sun setting through a dense forest of trees.\" /></figure>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:33.62%\">
<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-02.jpg\" alt=\"Wind turbines standing on a grassy plain, against a blue sky.\" /></figure>
</div>
</div>



<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\" style=\"flex-basis:67%\">
<div class=\"wp-block-image\"><figure class=\"alignright size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-03.jpg\" alt=\"The sun shining over a ridge leading down into the shore. In the distance, a car drives down a road.\" /></figure></div>
</div>



<div class=\"wp-block-column is-vertically-aligned-center\" style=\"flex-basis:33%\">
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">Undoubtedly we have no questions to ask which are unanswerable. We must trust the perfection of the creation so far, as to believe that whatever curiosity the order of things has awakened in our minds, the order of things can satisfy. Every man&#8217;s condition is a solution in hieroglyphic to those inquiries he would put.</p>
</div>
</div>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:77:\"Three columns with images and text, with vertical spacing for an offset look.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:2:{i:0;s:7:\"columns\";i:1;s:8:\"featured\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:3980:\"<!-- wp:group {\"align\":\"full\",\"style\":{\"color\":{\"background\":\"#f8f4e4\"}}} -->
<div class=\"wp-block-group alignfull has-background\" style=\"background-color:#f8f4e4\"><!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:spacer -->
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:heading {\"level\":6,\"style\":{\"color\":{\"text\":\"#000000\"}}} -->
<h6 class=\"has-text-color\" style=\"color:#000000\">ECOSYSTEM</h6>
<!-- /wp:heading -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"lineHeight\":\"1.1\",\"fontSize\":\"5vw\"},\"color\":{\"text\":\"#000000\"}}} -->
<p class=\"has-text-color\" style=\"color:#000000;font-size:5vw;line-height:1.1\"><strong>Positive growth.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:spacer {\"height\":5} -->
<div style=\"height:5px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"33.38%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:33.38%\"><!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#000000\"}},\"fontSize\":\"extra-small\"} -->
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\"><em>Nature</em>, in the common sense, refers to essences unchanged by man; space, the air, the river, the leaf.&nbsp;<em>Art</em>&nbsp;is applied to the mixture of his will with the same things, as in a house, a canal, a statue, a picture. But his operations taken together are so insignificant, a little chipping, baking, patching, and washing, that in an impression so grand as that of the world on the human mind, they do not vary the result.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":\"33%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:33%\"><!-- wp:spacer -->
<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-01.jpg\" alt=\"The sun setting through a dense forest of trees.\" /></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":\"33.62%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:33.62%\"><!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-02.jpg\" alt=\"Wind turbines standing on a grassy plain, against a blue sky.\" /></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"67%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:67%\"><!-- wp:image {\"align\":\"right\",\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<div class=\"wp-block-image\"><figure class=\"alignright size-large\"><img src=\"https://s.w.org/images/core/5.8/outside-03.jpg\" alt=\"The sun shining over a ridge leading down into the shore. In the distance, a car drives down a road.\" /></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"verticalAlignment\":\"center\",\"width\":\"33%\"} -->
<div class=\"wp-block-column is-vertically-aligned-center\" style=\"flex-basis:33%\"><!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#000000\"}},\"fontSize\":\"extra-small\"} -->
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">Undoubtedly we have no questions to ask which are unanswerable. We must trust the perfection of the creation so far, as to believe that whatever curiosity the order of things has awakened in our minds, the order of things can satisfy. Every man\'s condition is a solution in hieroglyphic to those inquiries he would put.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->\";}i:22;O:8:\"stdClass\":7:{s:2:\"id\";i:201;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:32:\"Three columns with offset images\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1077:\"
<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\" style=\"flex-basis:25%\">
<figure class=\"wp-block-image size-large is-style-default\"><img src=\"https://s.w.org/images/core/5.8/architecture-01.jpg\" alt=\"Close-up, abstract view of geometric architecture.\" /></figure>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:25%\">
<div style=\"height:500px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<div style=\"height:150px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/architecture-02.jpg\" alt=\"Close-up, angled view of a window on a white building.\" /></figure>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:45%\">
<figure class=\"wp-block-image size-large is-style-default\"><img src=\"https://s.w.org/images/core/5.8/architecture-03.jpg\" alt=\"Close-up of the corner of a white, geometric building with both sharp points and round corners.\" /></figure>



<div style=\"height:285px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
</div>
</div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:33:\"Three columns with offset images.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:2:{i:0;s:7:\"gallery\";i:1;s:6:\"images\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1753:\"<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column {\"width\":\"25%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:25%\"><!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\",\"className\":\"is-style-default\"} -->
<figure class=\"wp-block-image size-large is-style-default\"><img src=\"https://s.w.org/images/core/5.8/architecture-01.jpg\" alt=\"Close-up, abstract view of geometric architecture.\" /></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":\"25%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:25%\"><!-- wp:spacer {\"height\":500} -->
<div style=\"height:500px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:spacer {\"height\":150} -->
<div style=\"height:150px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<figure class=\"wp-block-image size-large\"><img src=\"https://s.w.org/images/core/5.8/architecture-02.jpg\" alt=\"Close-up, angled view of a window on a white building.\" /></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":\"45%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:45%\"><!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\",\"className\":\"is-style-default\"} -->
<figure class=\"wp-block-image size-large is-style-default\"><img src=\"https://s.w.org/images/core/5.8/architecture-03.jpg\" alt=\"Close-up of the corner of a white, geometric building with both sharp points and round corners.\" /></figure>
<!-- /wp:image -->

<!-- wp:spacer {\"height\":285} -->
<div style=\"height:285px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->\";}i:23;O:8:\"stdClass\":7:{s:2:\"id\";i:29;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:29:\"Two columns of text and title\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1337:\"
<h2 style=\"font-size:38px;line-height:1.4\"><strong>The voyage had begun, and had begun happily with a soft blue sky, and a calm sea.</strong></h2>



<div class=\"wp-block-columns\">
<div class=\"wp-block-column\">
<p style=\"font-size:18px\">They followed her on to the deck. All the smoke and the houses had disappeared, and the ship was out in a wide space of sea very fresh and clear though pale in the early light. They had left London sitting on its mud. A very thin line of shadow tapered on the horizon, scarcely thick enough to stand the burden of Paris, which nevertheless rested upon it. They were free of roads, free of mankind, and the same exhilaration at their freedom ran through them all.</p>
</div>



<div class=\"wp-block-column\">
<p style=\"font-size:18px\">The ship was making her way steadily through small waves which slapped her and then fizzled like effervescing water, leaving a little border of bubbles and foam on either side. The colourless October sky above was thinly clouded as if by the trail of wood-fire smoke, and the air was wonderfully salt and brisk. Indeed it was too cold to stand still. Mrs. Ambrose drew her arm within her husband&#8217;s, and as they moved off it could be seen from the way in which her sloping cheek turned up to his that she had something private to communicate.</p>
</div>
</div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:47:\"Two columns of text preceded by a long heading.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:2:{i:0;s:7:\"columns\";i:1;s:4:\"text\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:1711:\"<!-- wp:heading {\"style\":{\"typography\":{\"fontSize\":38,\"lineHeight\":\"1.4\"}}} -->
<h2 style=\"font-size:38px;line-height:1.4\"><strong>The voyage had begun, and had begun happily with a soft blue sky, and a calm sea.</strong></h2>
<!-- /wp:heading -->

<!-- wp:columns -->
<div class=\"wp-block-columns\"><!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":18}}} -->
<p style=\"font-size:18px\">They followed her on to the deck. All the smoke and the houses had disappeared, and the ship was out in a wide space of sea very fresh and clear though pale in the early light. They had left London sitting on its mud. A very thin line of shadow tapered on the horizon, scarcely thick enough to stand the burden of Paris, which nevertheless rested upon it. They were free of roads, free of mankind, and the same exhilaration at their freedom ran through them all.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":18}}} -->
<p style=\"font-size:18px\">The ship was making her way steadily through small waves which slapped her and then fizzled like effervescing water, leaving a little border of bubbles and foam on either side. The colourless October sky above was thinly clouded as if by the trail of wood-fire smoke, and the air was wonderfully salt and brisk. Indeed it was too cold to stand still. Mrs. Ambrose drew her arm within her husband\'s, and as they moved off it could be seen from the way in which her sloping cheek turned up to his that she had something private to communicate.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->\";}i:24;O:8:\"stdClass\":7:{s:2:\"id\";i:197;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:39:\"Two columns of text with offset heading\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:1915:\"
<div class=\"wp-container-6163e4b358e06 wp-block-group alignfull has-background\" style=\"background-color:#f2f0e9\"><div class=\"wp-block-group__inner-container\">
<div style=\"height:70px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>



<div class=\"wp-block-columns alignwide are-vertically-aligned-center\">
<div class=\"wp-block-column\" style=\"flex-basis:50%\">
<p class=\"has-text-color\" style=\"color:#000000;font-size:30px;line-height:1.1\"><strong>Oceanic Inspiration</strong></p>
</div>



<div class=\"wp-block-column\" style=\"flex-basis:50%\">
<hr class=\"wp-block-separator has-text-color has-background is-style-wide\" style=\"background-color:#000000;color:#000000\" />
</div>
</div>



<div class=\"wp-block-columns alignwide\">
<div class=\"wp-block-column\"></div>



<div class=\"wp-block-column\">
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">Winding veils round their heads, the women walked on deck. They were now moving steadily down the river, passing the dark shapes of ships at anchor, and London was a swarm of lights with a pale yellow canopy drooping above it. There were the lights of the great theatres, the lights of the long streets, lights that indicated huge squares of domestic comfort, lights that hung high in air.</p>
</div>



<div class=\"wp-block-column\">
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">No darkness would ever settle upon those lamps, as no darkness had settled upon them for hundreds of years. It seemed dreadful that the town should blaze for ever in the same spot; dreadful at least to people going away to adventure upon the sea, and beholding it as a circumscribed mound, eternally burnt, eternally scarred. From the deck of the ship the great city appeared a crouched and cowardly figure, a sedentary miser.</p>
</div>
</div>



<div style=\"height:40px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
</div></div>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:43:\"Two columns of text with an offset heading.\";s:19:\"wpop_viewport_width\";i:1200;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:2:{i:0;s:7:\"columns\";i:1;s:4:\"text\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:2837:\"<!-- wp:group {\"align\":\"full\",\"style\":{\"color\":{\"background\":\"#f2f0e9\"}}} -->
<div class=\"wp-block-group alignfull has-background\" style=\"background-color:#f2f0e9\"><!-- wp:spacer {\"height\":70} -->
<div style=\"height:70px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer -->

<!-- wp:columns {\"verticalAlignment\":\"center\",\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide are-vertically-aligned-center\"><!-- wp:column {\"width\":\"50%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:50%\"><!-- wp:paragraph {\"style\":{\"typography\":{\"lineHeight\":\"1.1\",\"fontSize\":\"30px\"},\"color\":{\"text\":\"#000000\"}}} -->
<p class=\"has-text-color\" style=\"color:#000000;font-size:30px;line-height:1.1\"><strong>Oceanic Inspiration</strong></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":\"50%\"} -->
<div class=\"wp-block-column\" style=\"flex-basis:50%\"><!-- wp:separator {\"customColor\":\"#000000\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator has-text-color has-background is-style-wide\" style=\"background-color:#000000;color:#000000\" />
<!-- /wp:separator --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {\"align\":\"wide\"} -->
<div class=\"wp-block-columns alignwide\"><!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#000000\"}},\"fontSize\":\"extra-small\"} -->
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">Winding veils round their heads, the women walked on deck. They were now moving steadily down the river, passing the dark shapes of ships at anchor, and London was a swarm of lights with a pale yellow canopy drooping above it. There were the lights of the great theatres, the lights of the long streets, lights that indicated huge squares of domestic comfort, lights that hung high in air.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph {\"style\":{\"color\":{\"text\":\"#000000\"}},\"fontSize\":\"extra-small\"} -->
<p class=\"has-text-color has-extra-small-font-size\" style=\"color:#000000\">No darkness would ever settle upon those lamps, as no darkness had settled upon them for hundreds of years. It seemed dreadful that the town should blaze for ever in the same spot; dreadful at least to people going away to adventure upon the sea, and beholding it as a circumscribed mound, eternally burnt, eternally scarred. From the deck of the ship the great city appeared a crouched and cowardly figure, a sedentary miser.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {\"height\":40} -->
<div style=\"height:40px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->\";}i:25;O:8:\"stdClass\":7:{s:2:\"id\";i:19;s:5:\"title\";O:8:\"stdClass\":1:{s:8:\"rendered\";s:23:\"Two images side by side\";}s:7:\"content\";O:8:\"stdClass\":2:{s:8:\"rendered\";s:647:\"
<figure class=\"wp-block-gallery alignwide columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://s.w.org/images/core/5.8/nature-above-01.jpg\" alt=\"An aerial view of waves crashing against a shore.\" data-full-url=\"https://s.w.org/images/core/5.8/nature-above-01.jpg\" data-link=\"#\" /></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://s.w.org/images/core/5.8/nature-above-02.jpg\" alt=\"An aerial view of a field. A road runs through the upper right corner.\" data-full-url=\"https://s.w.org/images/core/5.8/nature-above-02.jpg\" data-link=\"#\" /></figure></li></ul></figure>
\";s:9:\"protected\";b:0;}s:4:\"meta\";O:8:\"stdClass\":6:{s:10:\"spay_email\";s:0:\"\";s:13:\"wpop_keywords\";s:0:\"\";s:16:\"wpop_description\";s:41:\"An image gallery with two example images.\";s:19:\"wpop_viewport_width\";i:800;s:16:\"wpop_block_types\";a:0:{}s:11:\"wpop_locale\";s:5:\"en_US\";}s:14:\"category_slugs\";a:1:{i:0;s:7:\"gallery\";}s:13:\"keyword_slugs\";a:1:{i:0;s:4:\"core\";}s:15:\"pattern_content\";s:737:\"<!-- wp:gallery {\"ids\":[null,null],\"linkTo\":\"none\",\"align\":\"wide\"} -->
<figure class=\"wp-block-gallery alignwide columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://s.w.org/images/core/5.8/nature-above-01.jpg\" alt=\"An aerial view of waves crashing against a shore.\" data-full-url=\"https://s.w.org/images/core/5.8/nature-above-01.jpg\" data-link=\"#\" /></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://s.w.org/images/core/5.8/nature-above-02.jpg\" alt=\"An aerial view of a field. A road runs through the upper right corner.\" data-full-url=\"https://s.w.org/images/core/5.8/nature-above-02.jpg\" data-link=\"#\" /></figure></li></ul></figure>
<!-- /wp:gallery -->\";}}","no");
INSERT INTO `lh_options` VALUES("468","_transient_timeout_users_online","1634240596","no");
INSERT INTO `lh_options` VALUES("469","_transient_users_online","a:1:{i:0;a:4:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1634249596;s:10:\"ip_address\";s:9:\"127.0.0.1\";s:7:\"blog_id\";b:0;}}","no");
INSERT INTO `lh_options` VALUES("470","_transient_doing_cron","1634238799.2219660282135009765625","yes");


DROP TABLE IF EXISTS `lh_postmeta`;

CREATE TABLE `lh_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=619 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `lh_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `lh_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `lh_postmeta` VALUES("8","48","_wp_attached_file","2021/10/favIcon.svg");
INSERT INTO `lh_postmeta` VALUES("9","48","_wp_attachment_metadata","a:2:{s:5:\"width\";d:30;s:6:\"height\";d:28;}");
INSERT INTO `lh_postmeta` VALUES("10","47","_customize_restore_dismissed","1");
INSERT INTO `lh_postmeta` VALUES("11","49","_wp_trash_meta_status","publish");
INSERT INTO `lh_postmeta` VALUES("12","49","_wp_trash_meta_time","1633509909");
INSERT INTO `lh_postmeta` VALUES("13","50","_wp_attached_file","2021/10/logo.svg");
INSERT INTO `lh_postmeta` VALUES("14","50","_wp_attachment_metadata","a:2:{s:5:\"width\";d:88;s:6:\"height\";d:45;}");
INSERT INTO `lh_postmeta` VALUES("15","3","_wp_trash_meta_status","draft");
INSERT INTO `lh_postmeta` VALUES("16","3","_wp_trash_meta_time","1633512413");
INSERT INTO `lh_postmeta` VALUES("17","3","_wp_desired_post_slug","privacy-policy");
INSERT INTO `lh_postmeta` VALUES("18","2","_wp_trash_meta_status","publish");
INSERT INTO `lh_postmeta` VALUES("19","2","_wp_trash_meta_time","1633512415");
INSERT INTO `lh_postmeta` VALUES("20","2","_wp_desired_post_slug","sample-page");
INSERT INTO `lh_postmeta` VALUES("21","53","_edit_lock","1633805356:1");
INSERT INTO `lh_postmeta` VALUES("22","53","_wp_page_template","page-main.php");
INSERT INTO `lh_postmeta` VALUES("23","55","_wp_trash_meta_status","publish");
INSERT INTO `lh_postmeta` VALUES("24","55","_wp_trash_meta_time","1633512769");
INSERT INTO `lh_postmeta` VALUES("25","7","_edit_lock","1633630564:1");
INSERT INTO `lh_postmeta` VALUES("26","7","_edit_last","1");
INSERT INTO `lh_postmeta` VALUES("27","56","_wp_attached_file","2021/10/BK-150-1.jpg");
INSERT INTO `lh_postmeta` VALUES("28","56","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:750;s:4:\"file\";s:20:\"2021/10/BK-150-1.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"BK-150-1-300x117.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:117;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"BK-150-1-1024x400.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"BK-150-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"BK-150-1-768x300.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:21:\"BK-150-1-1536x600.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `lh_postmeta` VALUES("29","57","_wp_attached_file","2021/10/BK-250-1.jpg");
INSERT INTO `lh_postmeta` VALUES("30","57","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:750;s:4:\"file\";s:20:\"2021/10/BK-250-1.jpg\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"BK-250-1-300x117.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:117;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"BK-250-1-1024x400.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"BK-250-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"BK-250-1-768x300.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:21:\"BK-250-1-1536x600.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `lh_postmeta` VALUES("31","53","_edit_last","1");
INSERT INTO `lh_postmeta` VALUES("32","53","title_h1","производство домов");
INSERT INTO `lh_postmeta` VALUES("33","53","_title_h1","field_615c80301baec");
INSERT INTO `lh_postmeta` VALUES("34","53","title_p","из клеёного <span>бруса</span> <br> и оцилиндрованного <span>бревна</span>");
INSERT INTO `lh_postmeta` VALUES("35","53","_title_p","field_615c808fc0c0d");
INSERT INTO `lh_postmeta` VALUES("36","53","title_slider_0_slider_foto","56");
INSERT INTO `lh_postmeta` VALUES("37","53","_title_slider_0_slider_foto","field_615c822dc0c0f");
INSERT INTO `lh_postmeta` VALUES("38","53","title_slider_0_slider_title","");
INSERT INTO `lh_postmeta` VALUES("39","53","_title_slider_0_slider_title","field_615c83332ed0c");
INSERT INTO `lh_postmeta` VALUES("40","53","title_slider_1_slider_foto","57");
INSERT INTO `lh_postmeta` VALUES("41","53","_title_slider_1_slider_foto","field_615c822dc0c0f");
INSERT INTO `lh_postmeta` VALUES("42","53","title_slider_1_slider_title","");
INSERT INTO `lh_postmeta` VALUES("43","53","_title_slider_1_slider_title","field_615c83332ed0c");
INSERT INTO `lh_postmeta` VALUES("44","53","title_slider","2");
INSERT INTO `lh_postmeta` VALUES("45","53","_title_slider","field_615c80e4c0c0e");
INSERT INTO `lh_postmeta` VALUES("46","58","title_h1","");
INSERT INTO `lh_postmeta` VALUES("47","58","_title_h1","field_615c80301baec");
INSERT INTO `lh_postmeta` VALUES("48","58","title_p","");
INSERT INTO `lh_postmeta` VALUES("49","58","_title_p","field_615c808fc0c0d");
INSERT INTO `lh_postmeta` VALUES("50","58","title_slider_0_slider_foto","56");
INSERT INTO `lh_postmeta` VALUES("51","58","_title_slider_0_slider_foto","field_615c822dc0c0f");
INSERT INTO `lh_postmeta` VALUES("52","58","title_slider_0_slider_title","");
INSERT INTO `lh_postmeta` VALUES("53","58","_title_slider_0_slider_title","field_615c83332ed0c");
INSERT INTO `lh_postmeta` VALUES("54","58","title_slider_1_slider_foto","57");
INSERT INTO `lh_postmeta` VALUES("55","58","_title_slider_1_slider_foto","field_615c822dc0c0f");
INSERT INTO `lh_postmeta` VALUES("56","58","title_slider_1_slider_title","");
INSERT INTO `lh_postmeta` VALUES("57","58","_title_slider_1_slider_title","field_615c83332ed0c");
INSERT INTO `lh_postmeta` VALUES("58","58","title_slider","2");
INSERT INTO `lh_postmeta` VALUES("59","58","_title_slider","field_615c80e4c0c0e");
INSERT INTO `lh_postmeta` VALUES("60","59","_edit_lock","1633629536:1");
INSERT INTO `lh_postmeta` VALUES("61","59","_wp_page_template","page-hause.php");
INSERT INTO `lh_postmeta` VALUES("62","61","_wp_attached_file","2021/10/whatsap.svg");
INSERT INTO `lh_postmeta` VALUES("63","61","_wp_attachment_metadata","a:2:{s:5:\"width\";d:37;s:6:\"height\";d:37;}");
INSERT INTO `lh_postmeta` VALUES("64","62","_wp_attached_file","2021/10/telegram.svg");
INSERT INTO `lh_postmeta` VALUES("65","62","_wp_attachment_metadata","a:2:{s:5:\"width\";d:37;s:6:\"height\";d:37;}");
INSERT INTO `lh_postmeta` VALUES("66","63","_wp_attached_file","2021/10/instagram.svg");
INSERT INTO `lh_postmeta` VALUES("67","63","_wp_attachment_metadata","a:2:{s:5:\"width\";d:36;s:6:\"height\";d:37;}");
INSERT INTO `lh_postmeta` VALUES("68","64","_wp_attached_file","2021/10/phone.svg");
INSERT INTO `lh_postmeta` VALUES("69","64","_wp_attachment_metadata","a:2:{s:5:\"width\";d:32;s:6:\"height\";d:33;}");
INSERT INTO `lh_postmeta` VALUES("70","1","_wp_trash_meta_status","publish");
INSERT INTO `lh_postmeta` VALUES("71","1","_wp_trash_meta_time","1633513883");
INSERT INTO `lh_postmeta` VALUES("72","1","_wp_desired_post_slug","%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80");
INSERT INTO `lh_postmeta` VALUES("73","1","_wp_trash_meta_comments_status","a:1:{i:1;s:1:\"1\";}");
INSERT INTO `lh_postmeta` VALUES("74","66","title_h1","производство домов");
INSERT INTO `lh_postmeta` VALUES("75","66","_title_h1","field_615c80301baec");
INSERT INTO `lh_postmeta` VALUES("76","66","title_p","из клеёного <span>бруса</span> <br> и оцилиндрованного <span>бревна</span>");
INSERT INTO `lh_postmeta` VALUES("77","66","_title_p","field_615c808fc0c0d");
INSERT INTO `lh_postmeta` VALUES("78","66","title_slider_0_slider_foto","56");
INSERT INTO `lh_postmeta` VALUES("79","66","_title_slider_0_slider_foto","field_615c822dc0c0f");
INSERT INTO `lh_postmeta` VALUES("80","66","title_slider_0_slider_title","");
INSERT INTO `lh_postmeta` VALUES("81","66","_title_slider_0_slider_title","field_615c83332ed0c");
INSERT INTO `lh_postmeta` VALUES("82","66","title_slider_1_slider_foto","57");
INSERT INTO `lh_postmeta` VALUES("83","66","_title_slider_1_slider_foto","field_615c822dc0c0f");
INSERT INTO `lh_postmeta` VALUES("84","66","title_slider_1_slider_title","");
INSERT INTO `lh_postmeta` VALUES("85","66","_title_slider_1_slider_title","field_615c83332ed0c");
INSERT INTO `lh_postmeta` VALUES("86","66","title_slider","2");
INSERT INTO `lh_postmeta` VALUES("87","66","_title_slider","field_615c80e4c0c0e");
INSERT INTO `lh_postmeta` VALUES("88","67","_edit_lock","1633513913:1");
INSERT INTO `lh_postmeta` VALUES("89","68","_wp_attached_file","2021/10/logoFooter.svg");
INSERT INTO `lh_postmeta` VALUES("90","68","_wp_attachment_metadata","a:2:{s:5:\"width\";d:87;s:6:\"height\";d:45;}");
INSERT INTO `lh_postmeta` VALUES("91","69","_wp_attached_file","2021/10/whatsapFooter.svg");
INSERT INTO `lh_postmeta` VALUES("92","69","_wp_attachment_metadata","a:2:{s:5:\"width\";d:24;s:6:\"height\";d:25;}");
INSERT INTO `lh_postmeta` VALUES("93","70","_wp_attached_file","2021/10/telegramFooter.svg");
INSERT INTO `lh_postmeta` VALUES("94","70","_wp_attachment_metadata","a:2:{s:5:\"width\";d:24;s:6:\"height\";d:25;}");
INSERT INTO `lh_postmeta` VALUES("95","71","_wp_attached_file","2021/10/instagramFooter.svg");
INSERT INTO `lh_postmeta` VALUES("96","71","_wp_attachment_metadata","a:2:{s:5:\"width\";d:24;s:6:\"height\";d:25;}");
INSERT INTO `lh_postmeta` VALUES("97","14","_edit_lock","1633715673:1");
INSERT INTO `lh_postmeta` VALUES("98","14","_edit_last","1");
INSERT INTO `lh_postmeta` VALUES("105","15","_edit_lock","1633629485:1");
INSERT INTO `lh_postmeta` VALUES("106","15","_edit_last","1");
INSERT INTO `lh_postmeta` VALUES("107","124","_edit_lock","1633632087:1");
INSERT INTO `lh_postmeta` VALUES("109","124","_edit_last","1");
INSERT INTO `lh_postmeta` VALUES("111","124","house\'s_0_name","");
INSERT INTO `lh_postmeta` VALUES("112","124","_house\'s_0_name","field_615f1ddf36e51");
INSERT INTO `lh_postmeta` VALUES("113","124","house\'s_0_photos_0_photo_1","");
INSERT INTO `lh_postmeta` VALUES("114","124","_house\'s_0_photos_0_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("115","124","house\'s_0_photos_1_photo_1","");
INSERT INTO `lh_postmeta` VALUES("116","124","_house\'s_0_photos_1_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("117","124","house\'s_0_photos","2");
INSERT INTO `lh_postmeta` VALUES("118","124","_house\'s_0_photos","field_615f224836e52");
INSERT INTO `lh_postmeta` VALUES("119","124","house\'s_0_square","");
INSERT INTO `lh_postmeta` VALUES("120","124","_house\'s_0_square","field_615f28d2055a8");
INSERT INTO `lh_postmeta` VALUES("121","124","house\'s_0_specifications_room_icon","");
INSERT INTO `lh_postmeta` VALUES("122","124","_house\'s_0_specifications_room_icon","field_615f29dce9680");
INSERT INTO `lh_postmeta` VALUES("123","124","house\'s_0_specifications_room_number","");
INSERT INTO `lh_postmeta` VALUES("124","124","_house\'s_0_specifications_room_number","field_615f29f9e9681");
INSERT INTO `lh_postmeta` VALUES("125","124","house\'s_0_specifications_room","");
INSERT INTO `lh_postmeta` VALUES("126","124","_house\'s_0_specifications_room","field_615f299ce967f");
INSERT INTO `lh_postmeta` VALUES("127","124","house\'s_0_specifications_kitchen_icon","");
INSERT INTO `lh_postmeta` VALUES("128","124","_house\'s_0_specifications_kitchen_icon","field_615f2a5be9683");
INSERT INTO `lh_postmeta` VALUES("129","124","house\'s_0_specifications_kitchen_number","");
INSERT INTO `lh_postmeta` VALUES("130","124","_house\'s_0_specifications_kitchen_number","field_615f2a5be9684");
INSERT INTO `lh_postmeta` VALUES("131","124","house\'s_0_specifications_kitchen","");
INSERT INTO `lh_postmeta` VALUES("132","124","_house\'s_0_specifications_kitchen","field_615f2a5be9682");
INSERT INTO `lh_postmeta` VALUES("133","124","house\'s_0_specifications_toilet_icon","");
INSERT INTO `lh_postmeta` VALUES("134","124","_house\'s_0_specifications_toilet_icon","field_615f2a89e9686");
INSERT INTO `lh_postmeta` VALUES("135","124","house\'s_0_specifications_toilet_number","");
INSERT INTO `lh_postmeta` VALUES("136","124","_house\'s_0_specifications_toilet_number","field_615f2a89e9687");
INSERT INTO `lh_postmeta` VALUES("137","124","house\'s_0_specifications_toilet","");
INSERT INTO `lh_postmeta` VALUES("138","124","_house\'s_0_specifications_toilet","field_615f2a89e9685");
INSERT INTO `lh_postmeta` VALUES("139","124","house\'s_0_specifications_saunas_icon","");
INSERT INTO `lh_postmeta` VALUES("140","124","_house\'s_0_specifications_saunas_icon","field_615f2abce9689");
INSERT INTO `lh_postmeta` VALUES("141","124","house\'s_0_specifications_saunas_number","");
INSERT INTO `lh_postmeta` VALUES("142","124","_house\'s_0_specifications_saunas_number","field_615f2abce968a");
INSERT INTO `lh_postmeta` VALUES("143","124","house\'s_0_specifications_saunas","");
INSERT INTO `lh_postmeta` VALUES("144","124","_house\'s_0_specifications_saunas","field_615f2abce9688");
INSERT INTO `lh_postmeta` VALUES("145","124","house\'s_0_specifications_terraces_icon","");
INSERT INTO `lh_postmeta` VALUES("146","124","_house\'s_0_specifications_terraces_icon","field_615f2af5e968c");
INSERT INTO `lh_postmeta` VALUES("147","124","house\'s_0_specifications_terraces_number","");
INSERT INTO `lh_postmeta` VALUES("148","124","_house\'s_0_specifications_terraces_number","field_615f2af5e968d");
INSERT INTO `lh_postmeta` VALUES("149","124","house\'s_0_specifications_terraces","");
INSERT INTO `lh_postmeta` VALUES("150","124","_house\'s_0_specifications_terraces","field_615f2af5e968b");
INSERT INTO `lh_postmeta` VALUES("151","124","house\'s_0_specifications_balconies_icon","");
INSERT INTO `lh_postmeta` VALUES("152","124","_house\'s_0_specifications_balconies_icon","field_615f2b17e968f");
INSERT INTO `lh_postmeta` VALUES("153","124","house\'s_0_specifications_balconies_number","");
INSERT INTO `lh_postmeta` VALUES("154","124","_house\'s_0_specifications_balconies_number","field_615f2b17e9690");
INSERT INTO `lh_postmeta` VALUES("155","124","house\'s_0_specifications_balconies","");
INSERT INTO `lh_postmeta` VALUES("156","124","_house\'s_0_specifications_balconies","field_615f2b17e968e");
INSERT INTO `lh_postmeta` VALUES("157","124","house\'s_0_specifications","");
INSERT INTO `lh_postmeta` VALUES("158","124","_house\'s_0_specifications","field_615f2944e967e");
INSERT INTO `lh_postmeta` VALUES("159","124","house\'s_0_prices","");
INSERT INTO `lh_postmeta` VALUES("160","124","_house\'s_0_prices","field_615f2be28f396");
INSERT INTO `lh_postmeta` VALUES("161","124","house\'s_0_breading_0_plan","");
INSERT INTO `lh_postmeta` VALUES("162","124","_house\'s_0_breading_0_plan","field_615f2d74b175c");
INSERT INTO `lh_postmeta` VALUES("163","124","house\'s_0_breading","1");
INSERT INTO `lh_postmeta` VALUES("164","124","_house\'s_0_breading","field_615f2d41b175b");
INSERT INTO `lh_postmeta` VALUES("165","124","house\'s_0_Facades_0_imeg","");
INSERT INTO `lh_postmeta` VALUES("166","124","_house\'s_0_Facades_0_imeg","field_615f2e281576a");
INSERT INTO `lh_postmeta` VALUES("167","124","house\'s_0_Facades_1_imeg","");
INSERT INTO `lh_postmeta` VALUES("168","124","_house\'s_0_Facades_1_imeg","field_615f2e281576a");
INSERT INTO `lh_postmeta` VALUES("169","124","house\'s_0_Facades","2");
INSERT INTO `lh_postmeta` VALUES("170","124","_house\'s_0_Facades","field_615f2df415769");
INSERT INTO `lh_postmeta` VALUES("171","124","house\'s_0_balk_Elements","");
INSERT INTO `lh_postmeta` VALUES("172","124","_house\'s_0_balk_Elements","field_615f2f8910ced");
INSERT INTO `lh_postmeta` VALUES("173","124","house\'s_0_balk_overlaps","");
INSERT INTO `lh_postmeta` VALUES("174","124","_house\'s_0_balk_overlaps","field_615f309c10cf1");
INSERT INTO `lh_postmeta` VALUES("175","124","house\'s_0_balk_roofs","");
INSERT INTO `lh_postmeta` VALUES("176","124","_house\'s_0_balk_roofs","field_615f30b810cf3");
INSERT INTO `lh_postmeta` VALUES("177","124","house\'s_0_balk","");
INSERT INTO `lh_postmeta` VALUES("178","124","_house\'s_0_balk","field_615f2f3910ceb");
INSERT INTO `lh_postmeta` VALUES("179","124","house\'s_0_log_Elements","");
INSERT INTO `lh_postmeta` VALUES("180","124","_house\'s_0_log_Elements","field_615f30e210cf6");
INSERT INTO `lh_postmeta` VALUES("181","124","house\'s_0_log_overlaps","");
INSERT INTO `lh_postmeta` VALUES("182","124","_house\'s_0_log_overlaps","field_615f30e210cf8");
INSERT INTO `lh_postmeta` VALUES("183","124","house\'s_0_log_roofs","");
INSERT INTO `lh_postmeta` VALUES("184","124","_house\'s_0_log_roofs","field_615f30e210cfa");
INSERT INTO `lh_postmeta` VALUES("185","124","house\'s_0_log","");
INSERT INTO `lh_postmeta` VALUES("186","124","_house\'s_0_log","field_615f30e210cf5");
INSERT INTO `lh_postmeta` VALUES("187","124","house\'s","1");
INSERT INTO `lh_postmeta` VALUES("188","124","_house\'s","field_615eb13253b5f");
INSERT INTO `lh_postmeta` VALUES("189","125","house\'s_0_name","");
INSERT INTO `lh_postmeta` VALUES("190","125","_house\'s_0_name","field_615f1ddf36e51");
INSERT INTO `lh_postmeta` VALUES("191","125","house\'s_0_photos_0_photo_1","");
INSERT INTO `lh_postmeta` VALUES("192","125","_house\'s_0_photos_0_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("193","125","house\'s_0_photos_1_photo_1","");
INSERT INTO `lh_postmeta` VALUES("194","125","_house\'s_0_photos_1_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("195","125","house\'s_0_photos","2");
INSERT INTO `lh_postmeta` VALUES("196","125","_house\'s_0_photos","field_615f224836e52");
INSERT INTO `lh_postmeta` VALUES("197","125","house\'s_0_square","");
INSERT INTO `lh_postmeta` VALUES("198","125","_house\'s_0_square","field_615f28d2055a8");
INSERT INTO `lh_postmeta` VALUES("199","125","house\'s_0_specifications_room_icon","");
INSERT INTO `lh_postmeta` VALUES("200","125","_house\'s_0_specifications_room_icon","field_615f29dce9680");
INSERT INTO `lh_postmeta` VALUES("201","125","house\'s_0_specifications_room_number","");
INSERT INTO `lh_postmeta` VALUES("202","125","_house\'s_0_specifications_room_number","field_615f29f9e9681");
INSERT INTO `lh_postmeta` VALUES("203","125","house\'s_0_specifications_room","");
INSERT INTO `lh_postmeta` VALUES("204","125","_house\'s_0_specifications_room","field_615f299ce967f");
INSERT INTO `lh_postmeta` VALUES("205","125","house\'s_0_specifications_kitchen_icon","");
INSERT INTO `lh_postmeta` VALUES("206","125","_house\'s_0_specifications_kitchen_icon","field_615f2a5be9683");
INSERT INTO `lh_postmeta` VALUES("207","125","house\'s_0_specifications_kitchen_number","");
INSERT INTO `lh_postmeta` VALUES("208","125","_house\'s_0_specifications_kitchen_number","field_615f2a5be9684");
INSERT INTO `lh_postmeta` VALUES("209","125","house\'s_0_specifications_kitchen","");
INSERT INTO `lh_postmeta` VALUES("210","125","_house\'s_0_specifications_kitchen","field_615f2a5be9682");
INSERT INTO `lh_postmeta` VALUES("211","125","house\'s_0_specifications_toilet_icon","");
INSERT INTO `lh_postmeta` VALUES("212","125","_house\'s_0_specifications_toilet_icon","field_615f2a89e9686");
INSERT INTO `lh_postmeta` VALUES("213","125","house\'s_0_specifications_toilet_number","");
INSERT INTO `lh_postmeta` VALUES("214","125","_house\'s_0_specifications_toilet_number","field_615f2a89e9687");
INSERT INTO `lh_postmeta` VALUES("215","125","house\'s_0_specifications_toilet","");
INSERT INTO `lh_postmeta` VALUES("216","125","_house\'s_0_specifications_toilet","field_615f2a89e9685");
INSERT INTO `lh_postmeta` VALUES("217","125","house\'s_0_specifications_saunas_icon","");
INSERT INTO `lh_postmeta` VALUES("218","125","_house\'s_0_specifications_saunas_icon","field_615f2abce9689");
INSERT INTO `lh_postmeta` VALUES("219","125","house\'s_0_specifications_saunas_number","");
INSERT INTO `lh_postmeta` VALUES("220","125","_house\'s_0_specifications_saunas_number","field_615f2abce968a");
INSERT INTO `lh_postmeta` VALUES("221","125","house\'s_0_specifications_saunas","");
INSERT INTO `lh_postmeta` VALUES("222","125","_house\'s_0_specifications_saunas","field_615f2abce9688");
INSERT INTO `lh_postmeta` VALUES("223","125","house\'s_0_specifications_terraces_icon","");
INSERT INTO `lh_postmeta` VALUES("224","125","_house\'s_0_specifications_terraces_icon","field_615f2af5e968c");
INSERT INTO `lh_postmeta` VALUES("225","125","house\'s_0_specifications_terraces_number","");
INSERT INTO `lh_postmeta` VALUES("226","125","_house\'s_0_specifications_terraces_number","field_615f2af5e968d");
INSERT INTO `lh_postmeta` VALUES("227","125","house\'s_0_specifications_terraces","");
INSERT INTO `lh_postmeta` VALUES("228","125","_house\'s_0_specifications_terraces","field_615f2af5e968b");
INSERT INTO `lh_postmeta` VALUES("229","125","house\'s_0_specifications_balconies_icon","");
INSERT INTO `lh_postmeta` VALUES("230","125","_house\'s_0_specifications_balconies_icon","field_615f2b17e968f");
INSERT INTO `lh_postmeta` VALUES("231","125","house\'s_0_specifications_balconies_number","");
INSERT INTO `lh_postmeta` VALUES("232","125","_house\'s_0_specifications_balconies_number","field_615f2b17e9690");
INSERT INTO `lh_postmeta` VALUES("233","125","house\'s_0_specifications_balconies","");
INSERT INTO `lh_postmeta` VALUES("234","125","_house\'s_0_specifications_balconies","field_615f2b17e968e");
INSERT INTO `lh_postmeta` VALUES("235","125","house\'s_0_specifications","");
INSERT INTO `lh_postmeta` VALUES("236","125","_house\'s_0_specifications","field_615f2944e967e");
INSERT INTO `lh_postmeta` VALUES("237","125","house\'s_0_prices","");
INSERT INTO `lh_postmeta` VALUES("238","125","_house\'s_0_prices","field_615f2be28f396");
INSERT INTO `lh_postmeta` VALUES("239","125","house\'s_0_breading_0_plan","");
INSERT INTO `lh_postmeta` VALUES("240","125","_house\'s_0_breading_0_plan","field_615f2d74b175c");
INSERT INTO `lh_postmeta` VALUES("241","125","house\'s_0_breading","1");
INSERT INTO `lh_postmeta` VALUES("242","125","_house\'s_0_breading","field_615f2d41b175b");
INSERT INTO `lh_postmeta` VALUES("243","125","house\'s_0_Facades_0_imeg","");
INSERT INTO `lh_postmeta` VALUES("244","125","_house\'s_0_Facades_0_imeg","field_615f2e281576a");
INSERT INTO `lh_postmeta` VALUES("245","125","house\'s_0_Facades_1_imeg","");
INSERT INTO `lh_postmeta` VALUES("246","125","_house\'s_0_Facades_1_imeg","field_615f2e281576a");
INSERT INTO `lh_postmeta` VALUES("247","125","house\'s_0_Facades","2");
INSERT INTO `lh_postmeta` VALUES("248","125","_house\'s_0_Facades","field_615f2df415769");
INSERT INTO `lh_postmeta` VALUES("249","125","house\'s_0_balk_Elements","");
INSERT INTO `lh_postmeta` VALUES("250","125","_house\'s_0_balk_Elements","field_615f2f8910ced");
INSERT INTO `lh_postmeta` VALUES("251","125","house\'s_0_balk_overlaps","");
INSERT INTO `lh_postmeta` VALUES("252","125","_house\'s_0_balk_overlaps","field_615f309c10cf1");
INSERT INTO `lh_postmeta` VALUES("253","125","house\'s_0_balk_roofs","");
INSERT INTO `lh_postmeta` VALUES("254","125","_house\'s_0_balk_roofs","field_615f30b810cf3");
INSERT INTO `lh_postmeta` VALUES("255","125","house\'s_0_balk","");
INSERT INTO `lh_postmeta` VALUES("256","125","_house\'s_0_balk","field_615f2f3910ceb");
INSERT INTO `lh_postmeta` VALUES("257","125","house\'s_0_log_Elements","");
INSERT INTO `lh_postmeta` VALUES("258","125","_house\'s_0_log_Elements","field_615f30e210cf6");
INSERT INTO `lh_postmeta` VALUES("259","125","house\'s_0_log_overlaps","");
INSERT INTO `lh_postmeta` VALUES("260","125","_house\'s_0_log_overlaps","field_615f30e210cf8");
INSERT INTO `lh_postmeta` VALUES("261","125","house\'s_0_log_roofs","");
INSERT INTO `lh_postmeta` VALUES("262","125","_house\'s_0_log_roofs","field_615f30e210cfa");
INSERT INTO `lh_postmeta` VALUES("263","125","house\'s_0_log","");
INSERT INTO `lh_postmeta` VALUES("264","125","_house\'s_0_log","field_615f30e210cf5");
INSERT INTO `lh_postmeta` VALUES("265","125","house\'s","1");
INSERT INTO `lh_postmeta` VALUES("266","125","_house\'s","field_615eb13253b5f");
INSERT INTO `lh_postmeta` VALUES("268","124","_wp_old_slug","%d0%b4%d0%be%d0%bc%d0%b0");
INSERT INTO `lh_postmeta` VALUES("269","124","_encloseme","1");
INSERT INTO `lh_postmeta` VALUES("348","124","_wp_trash_meta_status","publish");
INSERT INTO `lh_postmeta` VALUES("349","124","_wp_trash_meta_time","1633633455");
INSERT INTO `lh_postmeta` VALUES("350","124","_wp_desired_post_slug","home");
INSERT INTO `lh_postmeta` VALUES("351","127","_edit_lock","1633633519:1");
INSERT INTO `lh_postmeta` VALUES("352","127","_edit_last","1");
INSERT INTO `lh_postmeta` VALUES("353","127","house\'s_0_name","");
INSERT INTO `lh_postmeta` VALUES("354","127","_house\'s_0_name","field_615f1ddf36e51");
INSERT INTO `lh_postmeta` VALUES("355","127","house\'s_0_photos_0_photo_1","");
INSERT INTO `lh_postmeta` VALUES("356","127","_house\'s_0_photos_0_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("357","127","house\'s_0_photos_1_photo_1","");
INSERT INTO `lh_postmeta` VALUES("358","127","_house\'s_0_photos_1_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("359","127","house\'s_0_photos","2");
INSERT INTO `lh_postmeta` VALUES("360","127","_house\'s_0_photos","field_615f224836e52");
INSERT INTO `lh_postmeta` VALUES("361","127","house\'s_0_square","");
INSERT INTO `lh_postmeta` VALUES("362","127","_house\'s_0_square","field_615f28d2055a8");
INSERT INTO `lh_postmeta` VALUES("363","127","house\'s_0_specifications_room_icon","");
INSERT INTO `lh_postmeta` VALUES("364","127","_house\'s_0_specifications_room_icon","field_615f29dce9680");
INSERT INTO `lh_postmeta` VALUES("365","127","house\'s_0_specifications_room_number","");
INSERT INTO `lh_postmeta` VALUES("366","127","_house\'s_0_specifications_room_number","field_615f29f9e9681");
INSERT INTO `lh_postmeta` VALUES("367","127","house\'s_0_specifications_room","");
INSERT INTO `lh_postmeta` VALUES("368","127","_house\'s_0_specifications_room","field_615f299ce967f");
INSERT INTO `lh_postmeta` VALUES("369","127","house\'s_0_specifications_kitchen_icon","");
INSERT INTO `lh_postmeta` VALUES("370","127","_house\'s_0_specifications_kitchen_icon","field_615f2a5be9683");
INSERT INTO `lh_postmeta` VALUES("371","127","house\'s_0_specifications_kitchen_number","");
INSERT INTO `lh_postmeta` VALUES("372","127","_house\'s_0_specifications_kitchen_number","field_615f2a5be9684");
INSERT INTO `lh_postmeta` VALUES("373","127","house\'s_0_specifications_kitchen","");
INSERT INTO `lh_postmeta` VALUES("374","127","_house\'s_0_specifications_kitchen","field_615f2a5be9682");
INSERT INTO `lh_postmeta` VALUES("375","127","house\'s_0_specifications_toilet_icon","");
INSERT INTO `lh_postmeta` VALUES("376","127","_house\'s_0_specifications_toilet_icon","field_615f2a89e9686");
INSERT INTO `lh_postmeta` VALUES("377","127","house\'s_0_specifications_toilet_number","");
INSERT INTO `lh_postmeta` VALUES("378","127","_house\'s_0_specifications_toilet_number","field_615f2a89e9687");
INSERT INTO `lh_postmeta` VALUES("379","127","house\'s_0_specifications_toilet","");
INSERT INTO `lh_postmeta` VALUES("380","127","_house\'s_0_specifications_toilet","field_615f2a89e9685");
INSERT INTO `lh_postmeta` VALUES("381","127","house\'s_0_specifications_saunas_icon","");
INSERT INTO `lh_postmeta` VALUES("382","127","_house\'s_0_specifications_saunas_icon","field_615f2abce9689");
INSERT INTO `lh_postmeta` VALUES("383","127","house\'s_0_specifications_saunas_number","");
INSERT INTO `lh_postmeta` VALUES("384","127","_house\'s_0_specifications_saunas_number","field_615f2abce968a");
INSERT INTO `lh_postmeta` VALUES("385","127","house\'s_0_specifications_saunas","");
INSERT INTO `lh_postmeta` VALUES("386","127","_house\'s_0_specifications_saunas","field_615f2abce9688");
INSERT INTO `lh_postmeta` VALUES("387","127","house\'s_0_specifications_terraces_icon","");
INSERT INTO `lh_postmeta` VALUES("388","127","_house\'s_0_specifications_terraces_icon","field_615f2af5e968c");
INSERT INTO `lh_postmeta` VALUES("389","127","house\'s_0_specifications_terraces_number","");
INSERT INTO `lh_postmeta` VALUES("390","127","_house\'s_0_specifications_terraces_number","field_615f2af5e968d");
INSERT INTO `lh_postmeta` VALUES("391","127","house\'s_0_specifications_terraces","");
INSERT INTO `lh_postmeta` VALUES("392","127","_house\'s_0_specifications_terraces","field_615f2af5e968b");
INSERT INTO `lh_postmeta` VALUES("393","127","house\'s_0_specifications_balconies_icon","");
INSERT INTO `lh_postmeta` VALUES("394","127","_house\'s_0_specifications_balconies_icon","field_615f2b17e968f");
INSERT INTO `lh_postmeta` VALUES("395","127","house\'s_0_specifications_balconies_number","");
INSERT INTO `lh_postmeta` VALUES("396","127","_house\'s_0_specifications_balconies_number","field_615f2b17e9690");
INSERT INTO `lh_postmeta` VALUES("397","127","house\'s_0_specifications_balconies","");
INSERT INTO `lh_postmeta` VALUES("398","127","_house\'s_0_specifications_balconies","field_615f2b17e968e");
INSERT INTO `lh_postmeta` VALUES("399","127","house\'s_0_specifications","");
INSERT INTO `lh_postmeta` VALUES("400","127","_house\'s_0_specifications","field_615f2944e967e");
INSERT INTO `lh_postmeta` VALUES("401","127","house\'s_0_prices","");
INSERT INTO `lh_postmeta` VALUES("402","127","_house\'s_0_prices","field_615f2be28f396");
INSERT INTO `lh_postmeta` VALUES("403","127","house\'s_0_breading_0_plan","");
INSERT INTO `lh_postmeta` VALUES("404","127","_house\'s_0_breading_0_plan","field_615f2d74b175c");
INSERT INTO `lh_postmeta` VALUES("405","127","house\'s_0_breading","1");
INSERT INTO `lh_postmeta` VALUES("406","127","_house\'s_0_breading","field_615f2d41b175b");
INSERT INTO `lh_postmeta` VALUES("407","127","house\'s_0_Facades_0_imeg","");
INSERT INTO `lh_postmeta` VALUES("408","127","_house\'s_0_Facades_0_imeg","field_615f2e281576a");
INSERT INTO `lh_postmeta` VALUES("409","127","house\'s_0_Facades_1_imeg","");
INSERT INTO `lh_postmeta` VALUES("410","127","_house\'s_0_Facades_1_imeg","field_615f2e281576a");
INSERT INTO `lh_postmeta` VALUES("411","127","house\'s_0_Facades","2");
INSERT INTO `lh_postmeta` VALUES("412","127","_house\'s_0_Facades","field_615f2df415769");
INSERT INTO `lh_postmeta` VALUES("413","127","house\'s_0_balk_Elements","");
INSERT INTO `lh_postmeta` VALUES("414","127","_house\'s_0_balk_Elements","field_615f2f8910ced");
INSERT INTO `lh_postmeta` VALUES("415","127","house\'s_0_balk_overlaps","");
INSERT INTO `lh_postmeta` VALUES("416","127","_house\'s_0_balk_overlaps","field_615f309c10cf1");
INSERT INTO `lh_postmeta` VALUES("417","127","house\'s_0_balk_roofs","");
INSERT INTO `lh_postmeta` VALUES("418","127","_house\'s_0_balk_roofs","field_615f30b810cf3");
INSERT INTO `lh_postmeta` VALUES("419","127","house\'s_0_balk","");
INSERT INTO `lh_postmeta` VALUES("420","127","_house\'s_0_balk","field_615f2f3910ceb");
INSERT INTO `lh_postmeta` VALUES("421","127","house\'s_0_log_Elements","");
INSERT INTO `lh_postmeta` VALUES("422","127","_house\'s_0_log_Elements","field_615f30e210cf6");
INSERT INTO `lh_postmeta` VALUES("423","127","house\'s_0_log_overlaps","");
INSERT INTO `lh_postmeta` VALUES("424","127","_house\'s_0_log_overlaps","field_615f30e210cf8");
INSERT INTO `lh_postmeta` VALUES("425","127","house\'s_0_log_roofs","");
INSERT INTO `lh_postmeta` VALUES("426","127","_house\'s_0_log_roofs","field_615f30e210cfa");
INSERT INTO `lh_postmeta` VALUES("427","127","house\'s_0_log","");
INSERT INTO `lh_postmeta` VALUES("428","127","_house\'s_0_log","field_615f30e210cf5");
INSERT INTO `lh_postmeta` VALUES("429","127","house\'s","1");
INSERT INTO `lh_postmeta` VALUES("430","127","_house\'s","field_615eb13253b5f");
INSERT INTO `lh_postmeta` VALUES("431","127","_wp_old_slug","%d0%b4%d0%be%d0%bc");
INSERT INTO `lh_postmeta` VALUES("432","128","_edit_lock","1633714071:1");
INSERT INTO `lh_postmeta` VALUES("433","128","_edit_last","1");
INSERT INTO `lh_postmeta` VALUES("434","128","house\'s_0_name","");
INSERT INTO `lh_postmeta` VALUES("435","128","_house\'s_0_name","field_615f1ddf36e51");
INSERT INTO `lh_postmeta` VALUES("436","128","house\'s_0_photos_0_photo_1","");
INSERT INTO `lh_postmeta` VALUES("437","128","_house\'s_0_photos_0_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("438","128","house\'s_0_photos_1_photo_1","");
INSERT INTO `lh_postmeta` VALUES("439","128","_house\'s_0_photos_1_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("440","128","house\'s_0_photos","2");
INSERT INTO `lh_postmeta` VALUES("441","128","_house\'s_0_photos","field_615f224836e52");
INSERT INTO `lh_postmeta` VALUES("442","128","house\'s_0_square","");
INSERT INTO `lh_postmeta` VALUES("443","128","_house\'s_0_square","field_615f28d2055a8");
INSERT INTO `lh_postmeta` VALUES("444","128","house\'s_0_specifications_room_icon","");
INSERT INTO `lh_postmeta` VALUES("445","128","_house\'s_0_specifications_room_icon","field_615f29dce9680");
INSERT INTO `lh_postmeta` VALUES("446","128","house\'s_0_specifications_room_number","");
INSERT INTO `lh_postmeta` VALUES("447","128","_house\'s_0_specifications_room_number","field_615f29f9e9681");
INSERT INTO `lh_postmeta` VALUES("448","128","house\'s_0_specifications_room","");
INSERT INTO `lh_postmeta` VALUES("449","128","_house\'s_0_specifications_room","field_615f299ce967f");
INSERT INTO `lh_postmeta` VALUES("450","128","house\'s_0_specifications_kitchen_icon","");
INSERT INTO `lh_postmeta` VALUES("451","128","_house\'s_0_specifications_kitchen_icon","field_615f2a5be9683");
INSERT INTO `lh_postmeta` VALUES("452","128","house\'s_0_specifications_kitchen_number","");
INSERT INTO `lh_postmeta` VALUES("453","128","_house\'s_0_specifications_kitchen_number","field_615f2a5be9684");
INSERT INTO `lh_postmeta` VALUES("454","128","house\'s_0_specifications_kitchen","");
INSERT INTO `lh_postmeta` VALUES("455","128","_house\'s_0_specifications_kitchen","field_615f2a5be9682");
INSERT INTO `lh_postmeta` VALUES("456","128","house\'s_0_specifications_toilet_icon","");
INSERT INTO `lh_postmeta` VALUES("457","128","_house\'s_0_specifications_toilet_icon","field_615f2a89e9686");
INSERT INTO `lh_postmeta` VALUES("458","128","house\'s_0_specifications_toilet_number","");
INSERT INTO `lh_postmeta` VALUES("459","128","_house\'s_0_specifications_toilet_number","field_615f2a89e9687");
INSERT INTO `lh_postmeta` VALUES("460","128","house\'s_0_specifications_toilet","");
INSERT INTO `lh_postmeta` VALUES("461","128","_house\'s_0_specifications_toilet","field_615f2a89e9685");
INSERT INTO `lh_postmeta` VALUES("462","128","house\'s_0_specifications_saunas_icon","");
INSERT INTO `lh_postmeta` VALUES("463","128","_house\'s_0_specifications_saunas_icon","field_615f2abce9689");
INSERT INTO `lh_postmeta` VALUES("464","128","house\'s_0_specifications_saunas_number","");
INSERT INTO `lh_postmeta` VALUES("465","128","_house\'s_0_specifications_saunas_number","field_615f2abce968a");
INSERT INTO `lh_postmeta` VALUES("466","128","house\'s_0_specifications_saunas","");
INSERT INTO `lh_postmeta` VALUES("467","128","_house\'s_0_specifications_saunas","field_615f2abce9688");
INSERT INTO `lh_postmeta` VALUES("468","128","house\'s_0_specifications_terraces_icon","");
INSERT INTO `lh_postmeta` VALUES("469","128","_house\'s_0_specifications_terraces_icon","field_615f2af5e968c");
INSERT INTO `lh_postmeta` VALUES("470","128","house\'s_0_specifications_terraces_number","");
INSERT INTO `lh_postmeta` VALUES("471","128","_house\'s_0_specifications_terraces_number","field_615f2af5e968d");
INSERT INTO `lh_postmeta` VALUES("472","128","house\'s_0_specifications_terraces","");
INSERT INTO `lh_postmeta` VALUES("473","128","_house\'s_0_specifications_terraces","field_615f2af5e968b");
INSERT INTO `lh_postmeta` VALUES("474","128","house\'s_0_specifications_balconies_icon","");
INSERT INTO `lh_postmeta` VALUES("475","128","_house\'s_0_specifications_balconies_icon","field_615f2b17e968f");
INSERT INTO `lh_postmeta` VALUES("476","128","house\'s_0_specifications_balconies_number","");
INSERT INTO `lh_postmeta` VALUES("477","128","_house\'s_0_specifications_balconies_number","field_615f2b17e9690");
INSERT INTO `lh_postmeta` VALUES("478","128","house\'s_0_specifications_balconies","");
INSERT INTO `lh_postmeta` VALUES("479","128","_house\'s_0_specifications_balconies","field_615f2b17e968e");
INSERT INTO `lh_postmeta` VALUES("480","128","house\'s_0_specifications","");
INSERT INTO `lh_postmeta` VALUES("481","128","_house\'s_0_specifications","field_615f2944e967e");
INSERT INTO `lh_postmeta` VALUES("482","128","house\'s_0_prices","");
INSERT INTO `lh_postmeta` VALUES("483","128","_house\'s_0_prices","field_615f2be28f396");
INSERT INTO `lh_postmeta` VALUES("484","128","house\'s_0_breading_0_plan","");
INSERT INTO `lh_postmeta` VALUES("485","128","_house\'s_0_breading_0_plan","field_615f2d74b175c");
INSERT INTO `lh_postmeta` VALUES("486","128","house\'s_0_breading","1");
INSERT INTO `lh_postmeta` VALUES("487","128","_house\'s_0_breading","field_615f2d41b175b");
INSERT INTO `lh_postmeta` VALUES("488","128","house\'s_0_Facades_0_imeg","");
INSERT INTO `lh_postmeta` VALUES("489","128","_house\'s_0_Facades_0_imeg","field_615f2e281576a");
INSERT INTO `lh_postmeta` VALUES("490","128","house\'s_0_Facades_1_imeg","");
INSERT INTO `lh_postmeta` VALUES("491","128","_house\'s_0_Facades_1_imeg","field_615f2e281576a");
INSERT INTO `lh_postmeta` VALUES("492","128","house\'s_0_Facades","2");
INSERT INTO `lh_postmeta` VALUES("493","128","_house\'s_0_Facades","field_615f2df415769");
INSERT INTO `lh_postmeta` VALUES("494","128","house\'s_0_balk_Elements","");
INSERT INTO `lh_postmeta` VALUES("495","128","_house\'s_0_balk_Elements","field_615f2f8910ced");
INSERT INTO `lh_postmeta` VALUES("496","128","house\'s_0_balk_overlaps","");
INSERT INTO `lh_postmeta` VALUES("497","128","_house\'s_0_balk_overlaps","field_615f309c10cf1");
INSERT INTO `lh_postmeta` VALUES("498","128","house\'s_0_balk_roofs","");
INSERT INTO `lh_postmeta` VALUES("499","128","_house\'s_0_balk_roofs","field_615f30b810cf3");
INSERT INTO `lh_postmeta` VALUES("500","128","house\'s_0_balk","");
INSERT INTO `lh_postmeta` VALUES("501","128","_house\'s_0_balk","field_615f2f3910ceb");
INSERT INTO `lh_postmeta` VALUES("502","128","house\'s_0_log_Elements","");
INSERT INTO `lh_postmeta` VALUES("503","128","_house\'s_0_log_Elements","field_615f30e210cf6");
INSERT INTO `lh_postmeta` VALUES("504","128","house\'s_0_log_overlaps","");
INSERT INTO `lh_postmeta` VALUES("505","128","_house\'s_0_log_overlaps","field_615f30e210cf8");
INSERT INTO `lh_postmeta` VALUES("506","128","house\'s_0_log_roofs","");
INSERT INTO `lh_postmeta` VALUES("507","128","_house\'s_0_log_roofs","field_615f30e210cfa");
INSERT INTO `lh_postmeta` VALUES("508","128","house\'s_0_log","");
INSERT INTO `lh_postmeta` VALUES("509","128","_house\'s_0_log","field_615f30e210cf5");
INSERT INTO `lh_postmeta` VALUES("510","128","house\'s","1");
INSERT INTO `lh_postmeta` VALUES("511","128","_house\'s","field_615eb13253b5f");
INSERT INTO `lh_postmeta` VALUES("512","127","_wp_trash_meta_status","publish");
INSERT INTO `lh_postmeta` VALUES("513","127","_wp_trash_meta_time","1633633553");
INSERT INTO `lh_postmeta` VALUES("514","127","_wp_desired_post_slug","hom");
INSERT INTO `lh_postmeta` VALUES("515","128","_wp_trash_meta_status","publish");
INSERT INTO `lh_postmeta` VALUES("516","128","_wp_trash_meta_time","1633714107");
INSERT INTO `lh_postmeta` VALUES("517","128","_wp_desired_post_slug","home");
INSERT INTO `lh_postmeta` VALUES("518","129","_edit_lock","1633714171:1");
INSERT INTO `lh_postmeta` VALUES("519","130","_edit_lock","1633714189:1");
INSERT INTO `lh_postmeta` VALUES("520","131","_edit_lock","1633714249:1");
INSERT INTO `lh_postmeta` VALUES("521","132","_edit_lock","1633714282:1");
INSERT INTO `lh_postmeta` VALUES("522","133","_edit_lock","1633714290:1");
INSERT INTO `lh_postmeta` VALUES("523","134","_edit_lock","1633714435:1");
INSERT INTO `lh_postmeta` VALUES("524","135","_edit_lock","1633714296:1");
INSERT INTO `lh_postmeta` VALUES("525","136","_edit_lock","1633715090:1");
INSERT INTO `lh_postmeta` VALUES("526","137","_edit_lock","1633714955:1");
INSERT INTO `lh_postmeta` VALUES("527","138","_edit_lock","1633715166:1");
INSERT INTO `lh_postmeta` VALUES("528","139","_edit_lock","1633715046:1");
INSERT INTO `lh_postmeta` VALUES("529","140","_edit_lock","1633936842:1");
INSERT INTO `lh_postmeta` VALUES("530","141","_wp_attached_file","2021/10/BK-124-1.jpg");
INSERT INTO `lh_postmeta` VALUES("531","141","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1170;s:6:\"height\";i:749;s:4:\"file\";s:20:\"2021/10/BK-124-1.jpg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"BK-124-1-300x192.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:192;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"BK-124-1-1024x656.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:656;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"BK-124-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"BK-124-1-768x492.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:492;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `lh_postmeta` VALUES("532","142","_wp_attached_file","2021/10/BK-124-2.jpg");
INSERT INTO `lh_postmeta` VALUES("533","142","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1170;s:6:\"height\";i:768;s:4:\"file\";s:20:\"2021/10/BK-124-2.jpg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"BK-124-2-300x197.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"BK-124-2-1024x672.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:672;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"BK-124-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"BK-124-2-768x504.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:504;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `lh_postmeta` VALUES("534","143","_wp_attached_file","2021/10/BK-124-3.jpg");
INSERT INTO `lh_postmeta` VALUES("535","143","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1170;s:6:\"height\";i:771;s:4:\"file\";s:20:\"2021/10/BK-124-3.jpg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"BK-124-3-300x198.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"BK-124-3-1024x675.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:675;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"BK-124-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"BK-124-3-768x506.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:506;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `lh_postmeta` VALUES("536","140","_edit_last","1");
INSERT INTO `lh_postmeta` VALUES("537","140","name","");
INSERT INTO `lh_postmeta` VALUES("538","140","_name","field_615f1ddf36e51");
INSERT INTO `lh_postmeta` VALUES("539","140","photos_0_photo_1","141");
INSERT INTO `lh_postmeta` VALUES("540","140","_photos_0_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("541","140","photos_1_photo_1","142");
INSERT INTO `lh_postmeta` VALUES("542","140","_photos_1_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("543","140","photos_2_photo_1","143");
INSERT INTO `lh_postmeta` VALUES("544","140","_photos_2_photo_1","field_615f229736e53");
INSERT INTO `lh_postmeta` VALUES("545","140","photos","3");
INSERT INTO `lh_postmeta` VALUES("546","140","_photos","field_615f224836e52");
INSERT INTO `lh_postmeta` VALUES("547","140","square","124");
INSERT INTO `lh_postmeta` VALUES("548","140","_square","field_615f28d2055a8");
INSERT INTO `lh_postmeta` VALUES("549","140","specifications_room_icon","");
INSERT INTO `lh_postmeta` VALUES("550","140","_specifications_room_icon","field_615f29dce9680");
INSERT INTO `lh_postmeta` VALUES("551","140","specifications_room_number","");
INSERT INTO `lh_postmeta` VALUES("552","140","_specifications_room_number","field_615f29f9e9681");
INSERT INTO `lh_postmeta` VALUES("553","140","specifications_room","");
INSERT INTO `lh_postmeta` VALUES("554","140","_specifications_room","field_615f299ce967f");
INSERT INTO `lh_postmeta` VALUES("555","140","specifications_kitchen_icon","");
INSERT INTO `lh_postmeta` VALUES("556","140","_specifications_kitchen_icon","field_615f2a5be9683");
INSERT INTO `lh_postmeta` VALUES("557","140","specifications_kitchen_number","");
INSERT INTO `lh_postmeta` VALUES("558","140","_specifications_kitchen_number","field_615f2a5be9684");
INSERT INTO `lh_postmeta` VALUES("559","140","specifications_kitchen","");
INSERT INTO `lh_postmeta` VALUES("560","140","_specifications_kitchen","field_615f2a5be9682");
INSERT INTO `lh_postmeta` VALUES("561","140","specifications_toilet_icon","");
INSERT INTO `lh_postmeta` VALUES("562","140","_specifications_toilet_icon","field_615f2a89e9686");
INSERT INTO `lh_postmeta` VALUES("563","140","specifications_toilet_number","");
INSERT INTO `lh_postmeta` VALUES("564","140","_specifications_toilet_number","field_615f2a89e9687");
INSERT INTO `lh_postmeta` VALUES("565","140","specifications_toilet","");
INSERT INTO `lh_postmeta` VALUES("566","140","_specifications_toilet","field_615f2a89e9685");
INSERT INTO `lh_postmeta` VALUES("567","140","specifications_saunas_icon","");
INSERT INTO `lh_postmeta` VALUES("568","140","_specifications_saunas_icon","field_615f2abce9689");
INSERT INTO `lh_postmeta` VALUES("569","140","specifications_saunas_number","");
INSERT INTO `lh_postmeta` VALUES("570","140","_specifications_saunas_number","field_615f2abce968a");
INSERT INTO `lh_postmeta` VALUES("571","140","specifications_saunas","");
INSERT INTO `lh_postmeta` VALUES("572","140","_specifications_saunas","field_615f2abce9688");
INSERT INTO `lh_postmeta` VALUES("573","140","specifications_terraces_icon","");
INSERT INTO `lh_postmeta` VALUES("574","140","_specifications_terraces_icon","field_615f2af5e968c");
INSERT INTO `lh_postmeta` VALUES("575","140","specifications_terraces_number","");
INSERT INTO `lh_postmeta` VALUES("576","140","_specifications_terraces_number","field_615f2af5e968d");
INSERT INTO `lh_postmeta` VALUES("577","140","specifications_terraces","");
INSERT INTO `lh_postmeta` VALUES("578","140","_specifications_terraces","field_615f2af5e968b");
INSERT INTO `lh_postmeta` VALUES("579","140","specifications_balconies_icon","");
INSERT INTO `lh_postmeta` VALUES("580","140","_specifications_balconies_icon","field_615f2b17e968f");
INSERT INTO `lh_postmeta` VALUES("581","140","specifications_balconies_number","");
INSERT INTO `lh_postmeta` VALUES("582","140","_specifications_balconies_number","field_615f2b17e9690");
INSERT INTO `lh_postmeta` VALUES("583","140","specifications_balconies","");
INSERT INTO `lh_postmeta` VALUES("584","140","_specifications_balconies","field_615f2b17e968e");
INSERT INTO `lh_postmeta` VALUES("585","140","specifications","");
INSERT INTO `lh_postmeta` VALUES("586","140","_specifications","field_615f2944e967e");
INSERT INTO `lh_postmeta` VALUES("587","140","prices","");
INSERT INTO `lh_postmeta` VALUES("588","140","_prices","field_615f2be28f396");
INSERT INTO `lh_postmeta` VALUES("589","140","breading_0_plan","");
INSERT INTO `lh_postmeta` VALUES("590","140","_breading_0_plan","field_615f2d74b175c");
INSERT INTO `lh_postmeta` VALUES("591","140","breading","1");
INSERT INTO `lh_postmeta` VALUES("592","140","_breading","field_615f2d41b175b");
INSERT INTO `lh_postmeta` VALUES("593","140","Facades_0_imeg","");
INSERT INTO `lh_postmeta` VALUES("594","140","_Facades_0_imeg","field_615f2e281576a");
INSERT INTO `lh_postmeta` VALUES("595","140","Facades_1_imeg","");
INSERT INTO `lh_postmeta` VALUES("596","140","_Facades_1_imeg","field_615f2e281576a");
INSERT INTO `lh_postmeta` VALUES("597","140","Facades","2");
INSERT INTO `lh_postmeta` VALUES("598","140","_Facades","field_615f2df415769");
INSERT INTO `lh_postmeta` VALUES("599","140","balk_Elements","");
INSERT INTO `lh_postmeta` VALUES("600","140","_balk_Elements","field_615f2f8910ced");
INSERT INTO `lh_postmeta` VALUES("601","140","balk_overlaps","");
INSERT INTO `lh_postmeta` VALUES("602","140","_balk_overlaps","field_615f309c10cf1");
INSERT INTO `lh_postmeta` VALUES("603","140","balk_roofs","");
INSERT INTO `lh_postmeta` VALUES("604","140","_balk_roofs","field_615f30b810cf3");
INSERT INTO `lh_postmeta` VALUES("605","140","balk","");
INSERT INTO `lh_postmeta` VALUES("606","140","_balk","field_615f2f3910ceb");
INSERT INTO `lh_postmeta` VALUES("607","140","log_Elements","");
INSERT INTO `lh_postmeta` VALUES("608","140","_log_Elements","field_615f30e210cf6");
INSERT INTO `lh_postmeta` VALUES("609","140","log_overlaps","");
INSERT INTO `lh_postmeta` VALUES("610","140","_log_overlaps","field_615f30e210cf8");
INSERT INTO `lh_postmeta` VALUES("611","140","log_roofs","");
INSERT INTO `lh_postmeta` VALUES("612","140","_log_roofs","field_615f30e210cfa");
INSERT INTO `lh_postmeta` VALUES("613","140","log","");
INSERT INTO `lh_postmeta` VALUES("614","140","_log","field_615f30e210cf5");
INSERT INTO `lh_postmeta` VALUES("615","144","_edit_lock","1633715617:1");
INSERT INTO `lh_postmeta` VALUES("616","140","_wp_page_template","page-hause.php");
INSERT INTO `lh_postmeta` VALUES("617","146","_wp_trash_meta_status","publish");
INSERT INTO `lh_postmeta` VALUES("618","146","_wp_trash_meta_time","1633865969");


DROP TABLE IF EXISTS `lh_posts`;

CREATE TABLE `lh_posts` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `lh_posts` VALUES("1","1","2021-10-06 11:21:30","2021-10-06 08:21:30","<!-- wp:paragraph -->
<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>
<!-- /wp:paragraph -->","Привет, мир!","","trash","open","open","","%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80__trashed","","","2021-10-06 12:51:23","2021-10-06 09:51:23","","0","http://localhost/?p=1","0","post","","1");
INSERT INTO `lh_posts` VALUES("2","1","2021-10-06 11:21:30","2021-10-06 08:21:30","<!-- wp:paragraph -->
<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...или так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>Перейдите <a href=\"http://localhost/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>
<!-- /wp:paragraph -->","Пример страницы","","trash","closed","open","","sample-page__trashed","","","2021-10-06 12:26:55","2021-10-06 09:26:55","","0","http://localhost/?page_id=2","0","page","","0");
INSERT INTO `lh_posts` VALUES("3","1","2021-10-06 11:21:30","2021-10-06 08:21:30","<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Наш адрес сайта: http://localhost.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->","Политика конфиденциальности","","trash","closed","open","","privacy-policy__trashed","","","2021-10-06 12:26:53","2021-10-06 09:26:53","","0","http://localhost/?page_id=3","0","page","","0");
INSERT INTO `lh_posts` VALUES("4","1","2021-10-06 11:21:40","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2021-10-06 11:21:40","0000-00-00 00:00:00","","0","http://localhost/?p=4","0","post","","0");
INSERT INTO `lh_posts` VALUES("7","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"53\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}","Главная страница","%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0","publish","closed","closed","","group_615b4fb32c72f","","","2021-10-07 21:18:25","2021-10-07 18:18:25","","0","http://localhost/?p=7","0","acf-field-group","","0");
INSERT INTO `lh_posts` VALUES("8","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}","Заголовок","","publish","closed","closed","","field_615c80171baeb","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","7","http://localhost/?post_type=acf-field&p=8","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("9","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Главный заголовок","title_h1","publish","closed","closed","","field_615c80301baec","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","7","http://localhost/?post_type=acf-field&p=9","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("10","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Подзаголовок","title_p","publish","closed","closed","","field_615c808fc0c0d","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","7","http://localhost/?post_type=acf-field&p=10","2","acf-field","","0");
INSERT INTO `lh_posts` VALUES("11","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";i:2;s:3:\"max\";i:8;s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}","Слайдер","title_slider","publish","closed","closed","","field_615c80e4c0c0e","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","7","http://localhost/?post_type=acf-field&p=11","3","acf-field","","0");
INSERT INTO `lh_posts` VALUES("12","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","Фотография","slider_foto","publish","closed","closed","","field_615c822dc0c0f","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","11","http://localhost/?post_type=acf-field&p=12","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("13","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","Заголовок","slider_title","publish","closed","closed","","field_615c83332ed0c","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","11","http://localhost/?post_type=acf-field&p=13","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("14","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:14:\"post_type_name\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}","Дома","%d0%b4%d0%be%d0%bc%d0%b0","publish","closed","closed","","group_615b4fda8263d","","","2021-10-08 20:31:10","2021-10-08 17:31:10","","0","http://localhost/?p=14","0","acf-field-group","","0");
INSERT INTO `lh_posts` VALUES("15","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:22:\"theme-general-settings\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"field\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}","Настройка шапки и подвала","%d0%bd%d0%b0%d1%81%d1%82%d1%80%d0%be%d0%b9%d0%ba%d0%b0-%d1%88%d0%b0%d0%bf%d0%ba%d0%b8-%d0%b8-%d0%bf%d0%be%d0%b4%d0%b2%d0%b0%d0%bb%d0%b0","publish","closed","closed","","group_61572d6952cee","","","2021-10-07 21:00:26","2021-10-07 18:00:26","","0","http://localhost/?p=15","4","acf-field-group","","0");
INSERT INTO `lh_posts` VALUES("16","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}","Шапка","","publish","closed","closed","","field_6159dffc16a47","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","15","http://localhost/?post_type=acf-field&p=16","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("17","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","Логотип шапки","logo_header","publish","closed","closed","","field_61572f175d223","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","15","http://localhost/?post_type=acf-field&p=17","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("18","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","Логотип","logo_icon","publish","closed","closed","","field_6157336b2c05f","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","17","http://localhost/?post_type=acf-field&p=18","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("19","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Ссылка","logo_link","publish","closed","closed","","field_615733b72c060","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","17","http://localhost/?post_type=acf-field&p=19","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("20","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","Иконки шапки","icon_header","publish","closed","closed","","field_6159e183d3202","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","15","http://localhost/?post_type=acf-field&p=20","2","acf-field","","0");
INSERT INTO `lh_posts` VALUES("21","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","WhatsApp","whatsapps","publish","closed","closed","","field_6159e184d3203","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","20","http://localhost/?post_type=acf-field&p=21","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("22","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","Иконка","whatsapp_icon","publish","closed","closed","","field_6159e184d3204","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","21","http://localhost/?post_type=acf-field&p=22","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("23","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Ссылка","whatsapps_link","publish","closed","closed","","field_6159e184d3205","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","21","http://localhost/?post_type=acf-field&p=23","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("24","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","Telegram","telegrams","publish","closed","closed","","field_6159e184d3206","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","20","http://localhost/?post_type=acf-field&p=24","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("25","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","Иконка","telegram_icon","publish","closed","closed","","field_6159e184d3207","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","24","http://localhost/?post_type=acf-field&p=25","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("26","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Ссылка","telegram_link","publish","closed","closed","","field_6159e184d3208","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","24","http://localhost/?post_type=acf-field&p=26","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("27","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","Instagram","instagrams","publish","closed","closed","","field_6159e184d3209","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","20","http://localhost/?post_type=acf-field&p=27","2","acf-field","","0");
INSERT INTO `lh_posts` VALUES("28","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","Иконка","telegram_icon","publish","closed","closed","","field_6159e184d320a","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","27","http://localhost/?post_type=acf-field&p=28","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("29","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Ссылка","instagram_link","publish","closed","closed","","field_6159e184d320b","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","27","http://localhost/?post_type=acf-field&p=29","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("30","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","Телефон","phone","publish","closed","closed","","field_6159e185d320c","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","20","http://localhost/?post_type=acf-field&p=30","3","acf-field","","0");
INSERT INTO `lh_posts` VALUES("31","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","иконка","icon","publish","closed","closed","","field_6159e185d320d","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","30","http://localhost/?post_type=acf-field&p=31","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("32","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","телефон","phone","publish","closed","closed","","field_6159e185d320e","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","30","http://localhost/?post_type=acf-field&p=32","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("33","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}","Подвал","","publish","closed","closed","","field_6159e0e6d31fe","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","15","http://localhost/?post_type=acf-field&p=33","3","acf-field","","0");
INSERT INTO `lh_posts` VALUES("34","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","Логотип подвала","logo_footer","publish","closed","closed","","field_6159e101d31ff","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","15","http://localhost/?post_type=acf-field&p=34","4","acf-field","","0");
INSERT INTO `lh_posts` VALUES("35","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","Логотип","logo_icon","publish","closed","closed","","field_6159e101d3200","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","34","http://localhost/?post_type=acf-field&p=35","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("36","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Ссылка","logo_link","publish","closed","closed","","field_6159e101d3201","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","34","http://localhost/?post_type=acf-field&p=36","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("37","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","Иконки подвала","icon_footer","publish","closed","closed","","field_6159f5ab71c5c","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","15","http://localhost/?post_type=acf-field&p=37","5","acf-field","","0");
INSERT INTO `lh_posts` VALUES("38","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","WhatsApp","whatsapp","publish","closed","closed","","field_6159f5e471c5d","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","37","http://localhost/?post_type=acf-field&p=38","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("39","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","Иконка","icon","publish","closed","closed","","field_6159f5fb71c5e","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","38","http://localhost/?post_type=acf-field&p=39","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("40","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Ссылка","link","publish","closed","closed","","field_6159f63571c5f","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","38","http://localhost/?post_type=acf-field&p=40","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("41","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","Instagram","instagram","publish","closed","closed","","field_6159f65571c60","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","37","http://localhost/?post_type=acf-field&p=41","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("42","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","Иконка","icon","publish","closed","closed","","field_6159f65571c61","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","41","http://localhost/?post_type=acf-field&p=42","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("43","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Ссылка","link","publish","closed","closed","","field_6159f65571c62","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","41","http://localhost/?post_type=acf-field&p=43","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("44","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","Telegram","telegram","publish","closed","closed","","field_6159f68471c63","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","37","http://localhost/?post_type=acf-field&p=44","2","acf-field","","0");
INSERT INTO `lh_posts` VALUES("45","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","Иконка","icon","publish","closed","closed","","field_6159f68471c64","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","44","http://localhost/?post_type=acf-field&p=45","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("46","1","2021-10-06 11:27:23","2021-10-06 08:27:23","a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}","Ссылка","link","publish","closed","closed","","field_6159f68471c65","","","2021-10-06 11:27:23","2021-10-06 08:27:23","","44","http://localhost/?post_type=acf-field&p=46","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("47","1","2021-10-06 11:43:07","0000-00-00 00:00:00","{
    \"blogdescription\": {
        \"value\": \"\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-10-06 08:43:07\"
    }
}","","","auto-draft","closed","closed","","205ec736-c1ed-4a33-a56b-97981af6b91f","","","2021-10-06 11:43:07","0000-00-00 00:00:00","","0","http://localhost/?p=47","0","customize_changeset","","0");
INSERT INTO `lh_posts` VALUES("48","1","2021-10-06 11:44:51","2021-10-06 08:44:51","","favIcon","","inherit","open","closed","","favicon","","","2021-10-06 11:44:51","2021-10-06 08:44:51","","0","http://localhost/wp-content/uploads/2021/10/favIcon.svg","0","attachment","image/svg+xml","0");
INSERT INTO `lh_posts` VALUES("49","1","2021-10-06 11:45:09","2021-10-06 08:45:09","{
    \"site_icon\": {
        \"value\": 48,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-10-06 08:45:09\"
    }
}","","","trash","closed","closed","","7e660d74-bb97-4231-bd28-585d0efe469d","","","2021-10-06 11:45:09","2021-10-06 08:45:09","","0","http://localhost/2021/10/06/7e660d74-bb97-4231-bd28-585d0efe469d/","0","customize_changeset","","0");
INSERT INTO `lh_posts` VALUES("50","1","2021-10-06 11:52:10","2021-10-06 08:52:10","","logo","","inherit","open","closed","","logo","","","2021-10-06 11:52:10","2021-10-06 08:52:10","","0","http://localhost/wp-content/uploads/2021/10/logo.svg","0","attachment","image/svg+xml","0");
INSERT INTO `lh_posts` VALUES("51","1","2021-10-06 12:26:53","2021-10-06 09:26:53","<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Наш адрес сайта: http://localhost.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->","Политика конфиденциальности","","inherit","closed","closed","","3-revision-v1","","","2021-10-06 12:26:53","2021-10-06 09:26:53","","3","http://localhost/?p=51","0","revision","","0");
INSERT INTO `lh_posts` VALUES("52","1","2021-10-06 12:26:55","2021-10-06 09:26:55","<!-- wp:paragraph -->
<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...или так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>Перейдите <a href=\"http://localhost/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>
<!-- /wp:paragraph -->","Пример страницы","","inherit","closed","closed","","2-revision-v1","","","2021-10-06 12:26:55","2021-10-06 09:26:55","","2","http://localhost/?p=52","0","revision","","0");
INSERT INTO `lh_posts` VALUES("53","1","2021-10-06 12:31:58","2021-10-06 09:31:58","","Главная страница","","publish","closed","closed","","%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0","","","2021-10-06 12:53:04","2021-10-06 09:53:04","","0","http://localhost/?page_id=53","0","page","","0");
INSERT INTO `lh_posts` VALUES("54","1","2021-10-06 12:31:58","2021-10-06 09:31:58","","Главная страница","","inherit","closed","closed","","53-revision-v1","","","2021-10-06 12:31:58","2021-10-06 09:31:58","","53","http://localhost/?p=54","0","revision","","0");
INSERT INTO `lh_posts` VALUES("55","1","2021-10-06 12:32:49","2021-10-06 09:32:49","{
    \"show_on_front\": {
        \"value\": \"page\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-10-06 09:32:49\"
    },
    \"page_on_front\": {
        \"value\": \"53\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-10-06 09:32:49\"
    }
}","","","trash","closed","closed","","9ca4ea14-2fd0-4dfd-8c00-52308710ed51","","","2021-10-06 12:32:49","2021-10-06 09:32:49","","0","http://localhost/2021/10/06/9ca4ea14-2fd0-4dfd-8c00-52308710ed51/","0","customize_changeset","","0");
INSERT INTO `lh_posts` VALUES("56","1","2021-10-06 12:33:56","2021-10-06 09:33:56","","BK-150-1","","inherit","open","closed","","bk-150-1","","","2021-10-06 12:33:56","2021-10-06 09:33:56","","53","http://localhost/wp-content/uploads/2021/10/BK-150-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `lh_posts` VALUES("57","1","2021-10-06 12:34:15","2021-10-06 09:34:15","","BK-250-1","","inherit","open","closed","","bk-250-1","","","2021-10-06 12:34:15","2021-10-06 09:34:15","","53","http://localhost/wp-content/uploads/2021/10/BK-250-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `lh_posts` VALUES("58","1","2021-10-06 12:34:19","2021-10-06 09:34:19","","Главная страница","","inherit","closed","closed","","53-revision-v1","","","2021-10-06 12:34:19","2021-10-06 09:34:19","","53","http://localhost/?p=58","0","revision","","0");
INSERT INTO `lh_posts` VALUES("59","1","2021-10-06 12:47:58","2021-10-06 09:47:58","","Дома","","publish","closed","closed","","hause","","","2021-10-06 12:47:58","2021-10-06 09:47:58","","0","http://localhost/?page_id=59","0","page","","0");
INSERT INTO `lh_posts` VALUES("60","1","2021-10-06 12:47:58","2021-10-06 09:47:58","","Дома","","inherit","closed","closed","","59-revision-v1","","","2021-10-06 12:47:58","2021-10-06 09:47:58","","59","http://localhost/?p=60","0","revision","","0");
INSERT INTO `lh_posts` VALUES("61","1","2021-10-06 12:49:03","2021-10-06 09:49:03","","whatsap","","inherit","open","closed","","whatsap","","","2021-10-06 12:49:03","2021-10-06 09:49:03","","0","http://localhost/wp-content/uploads/2021/10/whatsap.svg","0","attachment","image/svg+xml","0");
INSERT INTO `lh_posts` VALUES("62","1","2021-10-06 12:49:29","2021-10-06 09:49:29","","telegram","","inherit","open","closed","","telegram","","","2021-10-06 12:49:29","2021-10-06 09:49:29","","0","http://localhost/wp-content/uploads/2021/10/telegram.svg","0","attachment","image/svg+xml","0");
INSERT INTO `lh_posts` VALUES("63","1","2021-10-06 12:49:47","2021-10-06 09:49:47","","instagram","","inherit","open","closed","","instagram","","","2021-10-06 12:49:47","2021-10-06 09:49:47","","0","http://localhost/wp-content/uploads/2021/10/instagram.svg","0","attachment","image/svg+xml","0");
INSERT INTO `lh_posts` VALUES("64","1","2021-10-06 12:49:59","2021-10-06 09:49:59","","phone","","inherit","open","closed","","phone","","","2021-10-06 12:49:59","2021-10-06 09:49:59","","0","http://localhost/wp-content/uploads/2021/10/phone.svg","0","attachment","image/svg+xml","0");
INSERT INTO `lh_posts` VALUES("65","1","2021-10-06 12:51:23","2021-10-06 09:51:23","<!-- wp:paragraph -->
<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>
<!-- /wp:paragraph -->","Привет, мир!","","inherit","closed","closed","","1-revision-v1","","","2021-10-06 12:51:23","2021-10-06 09:51:23","","1","http://localhost/?p=65","0","revision","","0");
INSERT INTO `lh_posts` VALUES("66","1","2021-10-06 12:53:04","2021-10-06 09:53:04","","Главная страница","","inherit","closed","closed","","53-revision-v1","","","2021-10-06 12:53:04","2021-10-06 09:53:04","","53","http://localhost/?p=66","0","revision","","0");
INSERT INTO `lh_posts` VALUES("67","1","2021-10-06 12:54:14","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2021-10-06 12:54:14","0000-00-00 00:00:00","","0","http://localhost/?p=67","0","post","","0");
INSERT INTO `lh_posts` VALUES("68","1","2021-10-06 15:00:13","2021-10-06 12:00:13","","logoFooter","","inherit","open","closed","","logofooter","","","2021-10-06 15:00:13","2021-10-06 12:00:13","","0","http://localhost/wp-content/uploads/2021/10/logoFooter.svg","0","attachment","image/svg+xml","0");
INSERT INTO `lh_posts` VALUES("69","1","2021-10-06 15:00:28","2021-10-06 12:00:28","","whatsapFooter","","inherit","open","closed","","whatsapfooter","","","2021-10-06 15:00:28","2021-10-06 12:00:28","","0","http://localhost/wp-content/uploads/2021/10/whatsapFooter.svg","0","attachment","image/svg+xml","0");
INSERT INTO `lh_posts` VALUES("70","1","2021-10-06 15:00:39","2021-10-06 12:00:39","","telegramFooter","","inherit","open","closed","","telegramfooter","","","2021-10-06 15:00:39","2021-10-06 12:00:39","","0","http://localhost/wp-content/uploads/2021/10/telegramFooter.svg","0","attachment","image/svg+xml","0");
INSERT INTO `lh_posts` VALUES("71","1","2021-10-06 15:00:59","2021-10-06 12:00:59","","instagramFooter","","inherit","open","closed","","instagramfooter","","","2021-10-06 15:00:59","2021-10-06 12:00:59","","0","http://localhost/wp-content/uploads/2021/10/instagramFooter.svg","0","attachment","image/svg+xml","0");
INSERT INTO `lh_posts` VALUES("76","1","2021-10-07 14:04:02","2021-10-07 11:04:02","a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}","Стартовая страница","","publish","closed","closed","","field_615ed39353b60","","","2021-10-08 20:31:10","2021-10-08 17:31:10","","14","http://localhost/?post_type=acf-field&#038;p=76","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("77","1","2021-10-07 14:04:02","2021-10-07 11:04:02","a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}","Планировка фассад","","publish","closed","closed","","field_615ed3d853b61","","","2021-10-08 20:31:10","2021-10-08 17:31:10","","14","http://localhost/?post_type=acf-field&#038;p=77","6","acf-field","","0");
INSERT INTO `lh_posts` VALUES("78","1","2021-10-07 14:04:02","2021-10-07 11:04:02","a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}","Комплектация","","publish","closed","closed","","field_615ed40653b62","","","2021-10-08 20:31:10","2021-10-08 17:31:10","","14","http://localhost/?post_type=acf-field&#038;p=78","9","acf-field","","0");
INSERT INTO `lh_posts` VALUES("80","1","2021-10-07 19:41:18","2021-10-07 16:41:18","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","название проекта","name","publish","closed","closed","","field_615f1ddf36e51","","","2021-10-08 20:26:45","2021-10-08 17:26:45","","14","http://localhost/?post_type=acf-field&#038;p=80","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("81","1","2021-10-07 19:41:18","2021-10-07 16:41:18","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";i:2;s:3:\"max\";i:10;s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}","фотографии","photos","publish","closed","closed","","field_615f224836e52","","","2021-10-08 20:26:45","2021-10-08 17:26:45","","14","http://localhost/?post_type=acf-field&#038;p=81","2","acf-field","","0");
INSERT INTO `lh_posts` VALUES("82","1","2021-10-07 19:41:18","2021-10-07 16:41:18","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","фото","photo_1","publish","closed","closed","","field_615f229736e53","","","2021-10-07 19:47:04","2021-10-07 16:47:04","","81","http://localhost/?post_type=acf-field&#038;p=82","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("83","1","2021-10-07 20:07:06","2021-10-07 17:07:06","a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}","площадь","square","publish","closed","closed","","field_615f28d2055a8","","","2021-10-08 20:26:45","2021-10-08 17:26:45","","14","http://localhost/?post_type=acf-field&#038;p=83","3","acf-field","","0");
INSERT INTO `lh_posts` VALUES("84","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","характеристики","specifications","publish","closed","closed","","field_615f2944e967e","","","2021-10-08 20:26:45","2021-10-08 17:26:45","","14","http://localhost/?post_type=acf-field&#038;p=84","4","acf-field","","0");
INSERT INTO `lh_posts` VALUES("85","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","комнат","room","publish","closed","closed","","field_615f299ce967f","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","84","http://localhost/?post_type=acf-field&p=85","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("86","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:0:\"\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:0:\"\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","иконка","icon","publish","closed","closed","","field_615f29dce9680","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","85","http://localhost/?post_type=acf-field&p=86","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("87","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}","количество","number","publish","closed","closed","","field_615f29f9e9681","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","85","http://localhost/?post_type=acf-field&p=87","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("88","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","кухонь","kitchen","publish","closed","closed","","field_615f2a5be9682","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","84","http://localhost/?post_type=acf-field&p=88","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("89","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:0:\"\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:0:\"\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","иконка","icon","publish","closed","closed","","field_615f2a5be9683","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","88","http://localhost/?post_type=acf-field&p=89","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("90","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}","количество","number","publish","closed","closed","","field_615f2a5be9684","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","88","http://localhost/?post_type=acf-field&p=90","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("91","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","туалетов","toilet","publish","closed","closed","","field_615f2a89e9685","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","84","http://localhost/?post_type=acf-field&p=91","2","acf-field","","0");
INSERT INTO `lh_posts` VALUES("92","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:0:\"\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:0:\"\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","иконка","icon","publish","closed","closed","","field_615f2a89e9686","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","91","http://localhost/?post_type=acf-field&p=92","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("93","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}","количество","number","publish","closed","closed","","field_615f2a89e9687","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","91","http://localhost/?post_type=acf-field&p=93","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("94","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","сауны","saunas","publish","closed","closed","","field_615f2abce9688","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","84","http://localhost/?post_type=acf-field&p=94","3","acf-field","","0");
INSERT INTO `lh_posts` VALUES("95","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:0:\"\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:0:\"\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","иконка","icon","publish","closed","closed","","field_615f2abce9689","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","94","http://localhost/?post_type=acf-field&p=95","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("96","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}","количество","number","publish","closed","closed","","field_615f2abce968a","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","94","http://localhost/?post_type=acf-field&p=96","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("97","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","террас","terraces","publish","closed","closed","","field_615f2af5e968b","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","84","http://localhost/?post_type=acf-field&p=97","4","acf-field","","0");
INSERT INTO `lh_posts` VALUES("98","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:0:\"\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:0:\"\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","иконка","icon","publish","closed","closed","","field_615f2af5e968c","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","97","http://localhost/?post_type=acf-field&p=98","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("99","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}","количество","number","publish","closed","closed","","field_615f2af5e968d","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","97","http://localhost/?post_type=acf-field&p=99","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("100","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","балконов","balconies","publish","closed","closed","","field_615f2b17e968e","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","84","http://localhost/?post_type=acf-field&p=100","5","acf-field","","0");
INSERT INTO `lh_posts` VALUES("101","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","иконка","icon","publish","closed","closed","","field_615f2b17e968f","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","100","http://localhost/?post_type=acf-field&p=101","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("102","1","2021-10-07 20:15:38","2021-10-07 17:15:38","a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}","количество","number","publish","closed","closed","","field_615f2b17e9690","","","2021-10-07 20:15:38","2021-10-07 17:15:38","","100","http://localhost/?post_type=acf-field&p=102","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("103","1","2021-10-07 20:22:11","2021-10-07 17:22:11","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}","цена","prices","publish","closed","closed","","field_615f2be28f396","","","2021-10-08 20:26:45","2021-10-08 17:26:45","","14","http://localhost/?post_type=acf-field&#038;p=103","5","acf-field","","0");
INSERT INTO `lh_posts` VALUES("104","1","2021-10-07 20:22:11","2021-10-07 17:22:11","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","материал","material","publish","closed","closed","","field_615f2c2c8f397","","","2021-10-07 20:22:11","2021-10-07 17:22:11","","103","http://localhost/?post_type=acf-field&p=104","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("105","1","2021-10-07 20:22:11","2021-10-07 17:22:11","a:12:{s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}","цена","price","publish","closed","closed","","field_615f2c6e8f398","","","2021-10-07 20:22:11","2021-10-07 17:22:11","","103","http://localhost/?post_type=acf-field&p=105","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("106","1","2021-10-07 20:26:58","2021-10-07 17:26:58","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";i:1;s:3:\"max\";i:4;s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}","планировка","breading","publish","closed","closed","","field_615f2d41b175b","","","2021-10-08 20:26:45","2021-10-08 17:26:45","","14","http://localhost/?post_type=acf-field&#038;p=106","7","acf-field","","0");
INSERT INTO `lh_posts` VALUES("107","1","2021-10-07 20:26:58","2021-10-07 17:26:58","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","план этажа","plan","publish","closed","closed","","field_615f2d74b175c","","","2021-10-07 20:26:58","2021-10-07 17:26:58","","106","http://localhost/?post_type=acf-field&p=107","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("108","1","2021-10-07 20:29:44","2021-10-07 17:29:44","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";i:2;s:3:\"max\";i:4;s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}","Фасады","Facades","publish","closed","closed","","field_615f2df415769","","","2021-10-08 20:26:45","2021-10-08 17:26:45","","14","http://localhost/?post_type=acf-field&#038;p=108","8","acf-field","","0");
INSERT INTO `lh_posts` VALUES("109","1","2021-10-07 20:29:44","2021-10-07 17:29:44","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}","изображения","imeg","publish","closed","closed","","field_615f2e281576a","","","2021-10-07 20:29:44","2021-10-07 17:29:44","","108","http://localhost/?post_type=acf-field&p=109","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("110","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","брус","balk","publish","closed","closed","","field_615f2f3910ceb","","","2021-10-08 20:26:45","2021-10-08 17:26:45","","14","http://localhost/?post_type=acf-field&#038;p=110","10","acf-field","","0");
INSERT INTO `lh_posts` VALUES("111","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";i:10;s:6:\"layout\";s:0:\"\";s:12:\"button_label\";s:0:\"\";}","Элементы для сборки сруба","Elements","publish","closed","closed","","field_615f2f8910ced","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","110","http://localhost/?post_type=acf-field&p=111","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("112","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","элементы","enumeration","publish","closed","closed","","field_615f2fc510cee","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","111","http://localhost/?post_type=acf-field&p=112","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("113","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";i:10;s:6:\"layout\";s:0:\"\";s:12:\"button_label\";s:0:\"\";}","Элементы перекрытия дома","overlaps","publish","closed","closed","","field_615f309c10cf1","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","110","http://localhost/?post_type=acf-field&p=113","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("114","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","элементы","enumeration","publish","closed","closed","","field_615f309c10cf2","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","113","http://localhost/?post_type=acf-field&p=114","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("115","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";i:10;s:6:\"layout\";s:0:\"\";s:12:\"button_label\";s:0:\"\";}","Элементы кровли","roofs","publish","closed","closed","","field_615f30b810cf3","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","110","http://localhost/?post_type=acf-field&p=115","2","acf-field","","0");
INSERT INTO `lh_posts` VALUES("116","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","элементы","enumeration","publish","closed","closed","","field_615f30b810cf4","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","115","http://localhost/?post_type=acf-field&p=116","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("117","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}","бревно","log","publish","closed","closed","","field_615f30e210cf5","","","2021-10-08 20:26:45","2021-10-08 17:26:45","","14","http://localhost/?post_type=acf-field&#038;p=117","11","acf-field","","0");
INSERT INTO `lh_posts` VALUES("118","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";i:10;s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}","Элементы для сборки сруба","Elements","publish","closed","closed","","field_615f30e210cf6","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","117","http://localhost/?post_type=acf-field&p=118","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("119","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","элементы","enumeration","publish","closed","closed","","field_615f30e210cf7","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","118","http://localhost/?post_type=acf-field&p=119","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("120","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";i:10;s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}","Элементы перекрытия дома","overlaps","publish","closed","closed","","field_615f30e210cf8","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","117","http://localhost/?post_type=acf-field&p=120","1","acf-field","","0");
INSERT INTO `lh_posts` VALUES("121","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","элементы","enumeration","publish","closed","closed","","field_615f30e210cf9","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","120","http://localhost/?post_type=acf-field&p=121","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("122","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";i:10;s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}","Элементы кровли","roofs","publish","closed","closed","","field_615f30e210cfa","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","117","http://localhost/?post_type=acf-field&p=122","2","acf-field","","0");
INSERT INTO `lh_posts` VALUES("123","1","2021-10-07 20:40:45","2021-10-07 17:40:45","a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}","элементы","enumeration","publish","closed","closed","","field_615f30e210cfb","","","2021-10-07 20:40:45","2021-10-07 17:40:45","","122","http://localhost/?post_type=acf-field&p=123","0","acf-field","","0");
INSERT INTO `lh_posts` VALUES("124","1","2021-10-07 21:20:22","2021-10-07 18:20:22","","Дома","","trash","open","open","","home__trashed","","","2021-10-07 22:04:15","2021-10-07 19:04:15","","0","http://localhost/?p=124","0","post","","0");
INSERT INTO `lh_posts` VALUES("125","1","2021-10-07 21:20:22","2021-10-07 18:20:22","","Дома","","inherit","closed","closed","","124-revision-v1","","","2021-10-07 21:20:22","2021-10-07 18:20:22","","124","http://localhost/?p=125","0","revision","","0");
INSERT INTO `lh_posts` VALUES("127","1","2021-10-07 22:04:45","2021-10-07 19:04:45","","дом","","trash","closed","closed","","hom__trashed","","","2021-10-07 22:05:53","2021-10-07 19:05:53","","0","http://localhost/?post_type=post_type_name&#038;p=127","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("128","1","2021-10-07 22:05:43","2021-10-07 19:05:43","","дома","","trash","closed","closed","","home__trashed","","","2021-10-08 20:28:27","2021-10-08 17:28:27","","0","http://localhost/?post_type=post_type_name&#038;p=128","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("129","1","2021-10-08 20:28:30","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:28:30","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=129","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("130","1","2021-10-08 20:31:16","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:31:16","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=130","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("131","1","2021-10-08 20:32:22","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:32:22","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=131","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("132","1","2021-10-08 20:33:14","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:33:14","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=132","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("133","1","2021-10-08 20:33:47","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:33:47","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=133","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("134","1","2021-10-08 20:33:55","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:33:55","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=134","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("135","1","2021-10-08 20:33:57","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:33:57","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=135","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("136","1","2021-10-08 20:34:45","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:34:45","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=136","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("137","1","2021-10-08 20:44:53","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:44:53","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=137","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("138","1","2021-10-08 20:45:04","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:45:04","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=138","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("139","1","2021-10-08 20:46:18","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:46:18","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=139","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("140","1","2021-10-08 20:54:21","2021-10-08 17:54:21","","Зевс","","publish","closed","closed","","%d0%b7%d0%b5%d0%b2%d1%81","","","2021-10-09 22:09:54","2021-10-09 19:09:54","","0","http://localhost/?post_type=post_type_name&#038;p=140","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("141","1","2021-10-08 20:52:57","2021-10-08 17:52:57","","BK-124-1","","inherit","open","closed","","bk-124-1","","","2021-10-08 20:52:57","2021-10-08 17:52:57","","140","http://localhost/wp-content/uploads/2021/10/BK-124-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `lh_posts` VALUES("142","1","2021-10-08 20:53:07","2021-10-08 17:53:07","","BK-124-2","","inherit","open","closed","","bk-124-2","","","2021-10-08 20:53:07","2021-10-08 17:53:07","","140","http://localhost/wp-content/uploads/2021/10/BK-124-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `lh_posts` VALUES("143","1","2021-10-08 20:53:25","2021-10-08 17:53:25","","BK-124-3","","inherit","open","closed","","bk-124-3","","","2021-10-08 20:53:25","2021-10-08 17:53:25","","140","http://localhost/wp-content/uploads/2021/10/BK-124-3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `lh_posts` VALUES("144","1","2021-10-08 20:55:58","0000-00-00 00:00:00","","Черновик","","auto-draft","closed","closed","","","","","2021-10-08 20:55:58","0000-00-00 00:00:00","","0","http://localhost/?post_type=post_type_name&p=144","0","post_type_name","","0");
INSERT INTO `lh_posts` VALUES("146","1","2021-10-10 14:39:29","2021-10-10 11:39:29","{
    \"blogdescription\": {
        \"value\": \"\\u041f\\u0420\\u041e\\u0418\\u0417\\u0412\\u041e\\u0414\\u0421\\u0422\\u0412\\u041e \\u0414\\u041e\\u041c\\u041e\\u0412 \\u0438\\u0437 \\u043a\\u043b\\u0435\\u0451\\u043d\\u043e\\u0433\\u043e \\u0431\\u0440\\u0443\\u0441\\u0430 \\u0438 \\u043e\\u0446\\u0438\\u043b\\u0438\\u043d\\u0434\\u0440\\u043e\\u0432\\u0430\\u043d\\u043d\\u043e\\u0433\\u043e \\u0431\\u0440\\u0435\\u0432\\u043d\\u0430\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-10-10 11:39:29\"
    }
}","","","trash","closed","closed","","15207a05-41d6-48bb-820d-7348b52fe13a","","","2021-10-10 14:39:29","2021-10-10 11:39:29","","0","http://localhost/15207a05-41d6-48bb-820d-7348b52fe13a/%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8/","0","customize_changeset","","0");


DROP TABLE IF EXISTS `lh_term_relationships`;

CREATE TABLE `lh_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `lh_term_relationships` VALUES("1","1","0");
INSERT INTO `lh_term_relationships` VALUES("7","1","0");
INSERT INTO `lh_term_relationships` VALUES("14","1","0");
INSERT INTO `lh_term_relationships` VALUES("15","1","0");
INSERT INTO `lh_term_relationships` VALUES("124","1","0");


DROP TABLE IF EXISTS `lh_term_taxonomy`;

CREATE TABLE `lh_term_taxonomy` (
  `term_taxonomy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint unsigned NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `lh_term_taxonomy` VALUES("1","1","category","","0","0");


DROP TABLE IF EXISTS `lh_termmeta`;

CREATE TABLE `lh_termmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `lh_terms`;

CREATE TABLE `lh_terms` (
  `term_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `lh_terms` VALUES("1","Без рубрики","%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8","0");


DROP TABLE IF EXISTS `lh_usermeta`;

CREATE TABLE `lh_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `lh_usermeta` VALUES("1","1","nickname","@Filatov");
INSERT INTO `lh_usermeta` VALUES("2","1","first_name","Andrei");
INSERT INTO `lh_usermeta` VALUES("3","1","last_name","");
INSERT INTO `lh_usermeta` VALUES("4","1","description","");
INSERT INTO `lh_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `lh_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `lh_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `lh_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `lh_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `lh_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `lh_usermeta` VALUES("11","1","locale","");
INSERT INTO `lh_usermeta` VALUES("12","1","LH_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `lh_usermeta` VALUES("13","1","LH_user_level","10");
INSERT INTO `lh_usermeta` VALUES("14","1","dismissed_wp_pointers","plugin_editor_notice");
INSERT INTO `lh_usermeta` VALUES("15","1","show_welcome_panel","0");
INSERT INTO `lh_usermeta` VALUES("16","1","session_tokens","a:4:{s:64:\"9c2e95f71321da70a91170d9b395e3f5210dd359abb31727b09c6fc47ebd37b6\";a:4:{s:10:\"expiration\";i:1633681299;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:147:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 YaBrowser/21.9.0.1044 Yowser/2.5 Safari/537.36\";s:5:\"login\";i:1633508499;}s:64:\"d0529a612325aa75482dedb9595298f2faf14c9f25fb323d4a7cc0e6f3aec842\";a:4:{s:10:\"expiration\";i:1634719344;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:147:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 YaBrowser/21.9.0.1044 Yowser/2.5 Safari/537.36\";s:5:\"login\";i:1633509744;}s:64:\"8e9ce0650872240319b281c7a1c14b618cfdb3bb3ee6f4bce0c8dbaf070f8970\";a:4:{s:10:\"expiration\";i:1633795985;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36\";s:5:\"login\";i:1633623185;}s:64:\"1550037abe25c0393a9fc426c8bc7b612c16708d96910aa893f3f471a28b5c04\";a:4:{s:10:\"expiration\";i:1634839123;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36\";s:5:\"login\";i:1633629523;}}");
INSERT INTO `lh_usermeta` VALUES("17","1","LH_dashboard_quick_press_last_post_id","4");
INSERT INTO `lh_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");
INSERT INTO `lh_usermeta` VALUES("19","1","LH_user-settings","libraryContent=browse&ampmfold=o");
INSERT INTO `lh_usermeta` VALUES("20","1","LH_user-settings-time","1633936746");
INSERT INTO `lh_usermeta` VALUES("21","1","closedpostboxes_toplevel_page_theme-general-settings","a:0:{}");
INSERT INTO `lh_usermeta` VALUES("22","1","metaboxhidden_toplevel_page_theme-general-settings","a:0:{}");
INSERT INTO `lh_usermeta` VALUES("23","1","meta-box-order_toplevel_page_theme-general-settings","a:2:{s:4:\"side\";s:9:\"submitdiv\";s:6:\"normal\";s:23:\"acf-group_61572d6952cee\";}");
INSERT INTO `lh_usermeta` VALUES("24","1","screen_layout_toplevel_page_theme-general-settings","2");
INSERT INTO `lh_usermeta` VALUES("25","1","closedpostboxes_toplevel_page_aiowpsec","a:7:{i:0;s:25:\"security_points_breakdown\";i:1;s:15:\"spread_the_word\";i:2;s:15:\"know_developers\";i:3;s:23:\"critical_feature_status\";i:4;s:23:\"maintenance_mode_status\";i:5;s:15:\"logged_in_users\";i:6;s:19:\"locked_ip_addresses\";}");
INSERT INTO `lh_usermeta` VALUES("26","1","metaboxhidden_toplevel_page_aiowpsec","a:0:{}");
INSERT INTO `lh_usermeta` VALUES("27","1","last_login_time","2021-10-07 20:58:43");
INSERT INTO `lh_usermeta` VALUES("28","1","closedpostboxes_page","a:0:{}");
INSERT INTO `lh_usermeta` VALUES("29","1","metaboxhidden_page","a:0:{}");
INSERT INTO `lh_usermeta` VALUES("30","1","closedpostboxes_post_type_name","a:0:{}");
INSERT INTO `lh_usermeta` VALUES("31","1","metaboxhidden_post_type_name","a:0:{}");
INSERT INTO `lh_usermeta` VALUES("32","1","closedpostboxes_dashboard","a:5:{i:0;s:21:\"dashboard_site_health\";i:1;s:19:\"dashboard_right_now\";i:2;s:18:\"dashboard_activity\";i:3;s:21:\"dashboard_quick_press\";i:4;s:17:\"dashboard_primary\";}");
INSERT INTO `lh_usermeta` VALUES("33","1","metaboxhidden_dashboard","a:0:{}");


DROP TABLE IF EXISTS `lh_users`;

CREATE TABLE `lh_users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `lh_users` VALUES("1","@Filatov","$P$B4QHiECki8eLsoWOvsgwUUisAFmO8r1","filatov","schekotov@outlook.com","http://localhost","2021-10-06 08:21:30","","0","Andrei");


